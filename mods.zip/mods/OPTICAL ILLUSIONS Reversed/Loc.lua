local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_optic_illusions_desc" and "BASIC: ##2 points##\nYou are ##35%## less likely to be targeted by enemies.\n\nACE: ##4 points##\nYou gain ##1## concealment for reach silenced weapon you equip and reduces the concealment penalty of silencers by ##2##."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end