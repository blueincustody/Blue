local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.optic_illusions = {
		["name_id"] = "menu_optic_illusions",
		["desc_id"] = "menu_optic_illusions_desc",
		["icon_xy"] = {10, 10},
		[1] = {
			upgrades = {
				"player_camouflage_bonus_1",
				"player_camouflage_bonus_2",
				"player_silencer_concealment_penalty_decrease_1",
				"player_silencer_concealment_increase_1"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {
				"player_camouflage_bonus_1",
				"player_camouflage_bonus_2",
				"player_silencer_concealment_penalty_decrease_1",
				"player_silencer_concealment_increase_1"
			},
			cost = self.costs.hightierpro
		}
	}
end	