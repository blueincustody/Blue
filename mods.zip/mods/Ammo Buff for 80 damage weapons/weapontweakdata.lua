local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)
--Izhma
self.saiga.timers.reload_not_empty = 1.5
self.saiga.timers.reload_empty = self.saiga.timers.reload_not_empty
self.saiga.stats.concealment = 21
--Other
self.ksg.AMMO_PICKUP = {3,6}
self.huntsman.AMMO_PICKUP = {3,6}
self.ching.AMMO_PICKUP = {3,8}
self.lemming.AMMO_PICKUP = {5,10}
self.x_chinchilla.AMMO_PICKUP = {8,12}
self.m45.AMMO_PICKUP = {1.28, 4.48}
self.schakal.AMMO_PICKUP = {1.28, 4.48}
self.hajk.AMMO_PICKUP = {1.28, 4.48}
self.akmsu.AMMO_PICKUP = {1.28, 4.48}
self.flint.AMMO_PICKUP = {1.28, 4.48}
self.akm.AMMO_PICKUP = {1.28, 4.48}
self.m16.AMMO_PICKUP = {1.28, 4.48}
self.scar.AMMO_PICKUP = {1.28, 4.48}
self.g3.AMMO_PICKUP = {1.28, 4.48}
self.fal.AMMO_PICKUP = {8.84, 8.84}
self.x_akmsu.AMMO_PICKUP = {1.28, 4.48}
self.erma.AMMO_PICKUP = {1.28, 4.48}
end