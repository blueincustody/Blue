local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)
--Raven
self.ksg.fire_mode_data.fire_rate = 0.352
self.ksg.AMMO_PICKUP = {2,4}
self.ksg.timers.reload_empty = 3
self.ksg.timers.shotgun_reload_shell = 0.3
--Locomotive
self.serbu.timers.reload_empty = 1.5
self.serbu.timers.shotgun_reload_shell = 0.3
self.serbu.timers.shotgun_reload_first_shell_offset = 0.9
self.serbu.fire_mode_data.fire_rate = 0.352
--Street sweeper
self.striker.timers.shotgun_reload_first_shell_offset = 0.9
self.striker.timers.shotgun_reload_shell = 0.3
--Izhma
self.saiga.timers.reload_not_empty = 1.5
self.saiga.timers.reload_empty = self.saiga.timers.reload_not_empty
self.saiga.stats.concealment = 21
--Falcon
self.fal.AMMO_PICKUP = {6.84, 6.84}
self.fal.timers.reload_not_empty = 2
self.fal.timers.reload_empty = self.fal.timers.reload_not_empty
--Gewehr 3
self.g3.AMMO_PICKUP = {4.48, 4.48}
self.g3.stats.concealment = 18
self.g3.timers.reload_not_empty = 1.5
self.g3.timers.reload_empty = self.g3.timers.reload_not_empty
--Galant
self.ching.AMMO_PICKUP = {2.48,3.48}
self.ching.CAN_TOGGLE_FIREMODE = true
--Broomstick
self.c96.AMMO_PICKUP = {2,4}
self.c96.timers.reload_not_empty = 2
self.c96.timers.reload_empty = self.c96.timers.reload_not_empty
--Akimbo Castigo
self.x_chinchilla.AMMO_PICKUP = {4,8}
self.x_chinchilla.timers.reload_not_empty = 2
self.x_chinchilla.timers.reload_empty = self.x_chinchilla.timers.reload_not_empty
--Mosconi
self.huntsman.timers.reload_not_empty = 1.3
self.huntsman.timers.reload_empty = self.huntsman.timers.reload_not_empty
--The Judge
self.judge.AMMO_PICKUP = {2,4}
self.judge.timers.reload_not_empty = 1.5
self.judge.timers.reload_empty = self.judge.timers.reload_not_empty
self.judge.CAN_TOGGLE_FIREMODE = true
self.judge.auto = {}
self.judge.FIRE_MODE = "auto"
self.judge.auto.fire_rate = 0.00
self.judge.sounds.fire_single = "judge_fire"
self.judge.sounds.fire_auto = "judge_fire"
--Other
self.x_akmsu.AMMO_PICKUP = {1.28, 4.48}
self.huntsman.AMMO_PICKUP = {3,6}
self.lemming.AMMO_PICKUP = {3,5}
self.m45.AMMO_PICKUP = {1.28, 4.48}
self.schakal.AMMO_PICKUP = {1.28, 4.48}
self.hajk.AMMO_PICKUP = {1.28, 4.48}
self.akmsu.AMMO_PICKUP = {1.28, 4.48}
self.flint.AMMO_PICKUP = {1.28, 4.48}
self.akm.AMMO_PICKUP = {1.28, 4.48}
self.m16.AMMO_PICKUP = {1.28, 4.48}
self.scar.AMMO_PICKUP = {1.28, 4.48}
self.erma.AMMO_PICKUP = {1.28, 4.48}
self.m95.AMMO_PICKUP = {1,1}
end