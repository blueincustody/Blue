-- Those who live by the sword get shot by those who don't.

local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)
-- Primaries
	-- Assault Rifles
		--Falcon
		self.fal.timers.reload_not_empty = 1.5 --was 2.2
		self.fal.timers.reload_empty = self.fal.timers.reload_not_empty
		-- Golden AK7.62
		self.akm_gold.timers.reload_not_empty = 2 -- was 2.8
		-- AMCAR
		self.amcar.timers.reload_not_empty = 2.10 -- was 2.25
		self.amcar.timers.reload_empty = 2.9 -- was 3
		-- CAR-4
		self.new_m4.timers.reload_not_empty = 1.5 -- was 2.67
		self.new_m4.timers.reload_empty = self.new_m4.timers.reload_not_empty
		-- UAR
		self.aug.timers.reload_empty = 3.4 -- was 3.3
		-- AK7.62
		self.akm.timers.reload_not_empty = 2 -- was 2.8
		-- JP36
		self.g36.timers.reload_not_empty = 2.4 -- was 2.85
		-- M308
		self.new_m14.timers.reload_not_empty = 1.5 -- was 2.65
		-- AK5
		self.ak5.timers.reload_not_empty = 1.5 -- was 2.05
		self.ak5.timers.reload_empty = self.ak5.timers.reload_not_empty
		-- Commando 553
		self.s552.timers.reload_not_empty = 1.7 -- was 1.65
		self.s552.timers.reload_empty = 2.35 -- was 2.4
		-- Eagle Heavy
		self.scar.timers.reload_not_empty = 1.75 -- was 2.2
		-- Clarion
		self.famas.timers.reload_not_empty = 1.5 -- was 2.72
		self.famas.timers.reload_empty = self.famas.timers.reload_not_empty
		-- Gecko 7.62
		self.galil.timers.reload_not_empty = 1.5 -- was 3
		self.galil.timers.reload_empty = 1.5 -- was 4.2
		-- Gewehr 3
		self.g3.timers.reload_not_empty = 1.5 -- was 2.6
		-- Queen's Wrath
		self.l85a2.timers.reload_not_empty = 1.4 -- was 3.5
		self.l85a2.timers.reload_empty = 1.4 -- was 4.5
		-- Lion's Roar
		self.vhs.timers.reload_empty = 4.6 -- was 4.75
	-- Akimbo
		-- Akimbo Castigo
		self.x_chinchilla.timers.reload_not_empty = 1 -- was 3.47
		self.x_chinchilla.timers.reload_empty = self.x_chinchilla.timers.reload_not_empty
		-- Akimbo Krinkov
		self.x_akmsu.timers.reload_not_empty = 2.75 -- was 3
		self.x_akmsu.timers.reload_empty = 3.4 -- was 3.5
		-- Akimbo Compact-5
		self.x_mp5.timers.reload_not_empty = 1.95 -- was 2.5
		self.x_mp5.timers.reload_empty = 2.6 -- was 3
	-- Shotguns
		-- Mosconi 12G
		self.huntsman.timers.reload_not_empty = 0.5 -- was 2.5
		self.huntsman.timers.reload_empty = self.huntsman.timers.reload_not_empty
		-- Breaker 12G
		self.boot.timers.shotgun_reload_first_shell_offset = 0.15 -- was 0
	-- Special
		-- Piglet
		self.m32.timers.shotgun_reload_first_shell_offset = 1 -- was 0
		-- Flamethrower
		self.flamethrower_mk2.timers.reload_not_empty = 7.7 -- was 8.5
		self.flamethrower_mk2.timers.reload_empty = self.flamethrower_mk2.timers.reload_not_empty
		-- Light crossbow
		self.frankish.timers.reload_not_empty = 1.6 -- was 1.5
		self.frankish.timers.reload_empty = 1.6
		-- Heavy crossbow
		self.arblast.timers.reload_not_empty = 3.05 -- was 2.5
		self.arblast.timers.reload_empty = 3.05
	--Sniper Rifles
		-- Platypus Sniper Rifle
		self.model70.timers.reload_empty = 4.3 -- was 4.5
		-- Repeater 1874
		self.winchester1874.timers.shotgun_reload_first_shell_offset = 0.25 -- was 0.2
	-- Light Machine Guns
		-- KSP
		self.m249.timers.reload_not_empty = 5.5 -- was 5.62
		self.m249.timers.reload_empty = 5.5 -- was 5.62
		-- Buzzsaw 42
		self.mg42.timers.reload_not_empty = 6.25-- was 6.5
		self.mg42.timers.reload_empty = 6.25 -- was 6.5
-- Secondaries
	-- Submachine Guns
		-- Kobus 90
		self.p90.timers.reload_not_empty = 1 -- was 2.55
		self.p90.timers.reload_empty = 1.5 -- was 3.4
		-- Chicago Typewriter
		self.m1928.timers.reload_not_empty = 3.3 -- was 3.5
		-- Mark 10
		self.mac10.timers.reload_not_empty = 1.55 -- was 2
		self.mac10.timers.reload_empty = 2.4 -- was 2.7
		-- Heather
		self.sr2.timers.reload_not_empty = 2 -- was 2.07
		-- Krinkov
		self.akmsu.timers.reload_not_empty = 1.95 -- was 2.15
		self.akmsu.timers.reload_empty = 3.7 -- was 3.9
		-- Swedish K
		self.m45.timers.reload_not_empty = 1.5 -- was 2.85
		self.m45.timers.reload_empty = self.m45.timers.reload_not_empty
		-- SpecOps
		self.mp7.timers.reload_not_empty = 1.75 -- was 1.96
		self.mp7.timers.reload_empty = 2.4 -- was 2.45
		-- Cobra
		self.scorpion.timers.reload_not_empty = 1.95 -- was 2
		-- Jacket's Piece
		self.cobray.timers.reload_not_empty = 2 -- was 2.05
		self.cobray.timers.reload_empty = 4.25 -- was 4.35
		-- CR 805B
		self.hajk.timers.reload_not_empty = 1.9 -- was 2
		self.hajk.timers.reload_empty = 3.4 -- was 3.5
	--Pistols
		-- Bronco
		self.new_raging_bull.timers.reload_not_empty = 1 -- was 2.25
		self.new_raging_bull.timers.reload_empty = 1
		-- Gruber Kurz
		self.ppk.timers.reload_not_empty = 1.45 -- was 1.55
		self.ppk.timers.reload_empty = 2.2 -- was 2.12
		-- Broomstick
		self.c96.timers.reload_not_empty = 3.7 -- was 4
		-- Peacemaker
		self.peacemaker.timers.shotgun_reload_first_shell_offset = 0.5 -- was 0	
	-- Special
		-- HRL-7
		self.rpg7.timers.reload_not_empty = 3.25 -- was 4.7
		self.rpg7.timers.reload_empty = self.rpg7.timers.reload_not_empty
		-- China Puff
		self.china.timers.shotgun_reload_first_shell_offset = 0.5 -- was 0
	--Shotguns
		-- Street sweeper
		self.striker.timers.shotgun_reload_first_shell_offset = 0.1 -- was 0.13333334
end