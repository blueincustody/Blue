local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_awareness_beta_desc" and "BASIC: ##2 points##\nYou gain the ability to sprint in any direction.\nRun and reload - you can reload your weapons while sprinting.\n\nACE: ##4 points##\nYou gain ##10%## additional movement speed and ##20%## ladder climbing speed."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end