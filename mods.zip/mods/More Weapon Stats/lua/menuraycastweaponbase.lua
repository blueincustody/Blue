require("lib/units/weapons/RaycastWeaponBase")
require("lib/units/weapons/NewRaycastWeaponBase")
MoreWeaponStats_update_stats_values = NewRaycastWeaponBase._update_stats_values
