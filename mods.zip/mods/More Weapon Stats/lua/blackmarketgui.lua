_G.MoreWeaponStats = _G.MoreWeaponStats or {}

local mws_original_blackmarketgui_updateborders = BlackMarketGui._update_borders
function BlackMarketGui:_update_borders()
	mws_original_blackmarketgui_updateborders(self)

	if self._tabs[self._selected]._data.identifier == self.identifiers.weapon then
		local weapon_info_height, wh
		if MoreWeaponStats.settings.show_spread_and_recoil then
			self._panel:child("back_button"):set_right(self._box_panel:right())

			if self._detection_panel:visible() then
				self._detection_panel:set_right(self._panel:child("back_button"):left() - 8)
				self._detection_panel:set_center_y(self._panel:child("back_button"):center_y())
				self._detection_border:hide()
			end

			if self._btn_panel then
				self._btn_panel:set_bottom(self._panel:bottom())
			end

			wh = self._weapon_info_panel:h()
			weapon_info_height = self._panel:bottom() - (self._button_count > 0 and self._btn_panel:h() + 8 or 0) - self._weapon_info_panel:top()

		else
			self._panel:child("back_button"):set_right(self._panel:right())

			if self._detection_panel:visible() then
				self._detection_panel:set_right(self._box_panel:right())
				self._detection_panel:set_center_y(self._panel:child("back_button"):center_y())
				self._detection_border:hide()
			end

			if self._btn_panel then
				self._btn_panel:set_bottom(self._box_panel:bottom())
			end

			wh = self._weapon_info_panel:h()
			weapon_info_height = self._box_panel:bottom() - (self._button_count > 0 and self._btn_panel:h() + 8 or 0) - self._weapon_info_panel:top()
		end

		self._weapon_info_panel:set_h(weapon_info_height)
		self._stats_panel:set_h(weapon_info_height)
		self._rweapon_stats_panel:set_h(weapon_info_height)
		self._info_texts_panel:set_h(weapon_info_height - 20)
		if wh ~= self._weapon_info_panel:h() then
			self._weapon_info_border:create_sides(self._weapon_info_panel, { sides = { 1, 1, 1, 1 } })
		end
	end
end

local mws_original_blackmarketgui_setinfotext = BlackMarketGui.set_info_text
function BlackMarketGui:set_info_text(id, ...)
	mws_original_blackmarketgui_setinfotext(self, id, ...)

	if (id == 3 or id == 5 or (id == 4 and not MoreWeaponStats.settings.show_dlc_info)) then
		if self._tabs[self._selected]._data.identifier == self.identifiers.weapon then
			self._info_texts[id]:set_visible(false)
			if self._desc_mini_icons then
				for _, gui_object in pairs(self._desc_mini_icons) do
					self._panel:remove(gui_object[1])
				end
				self._desc_mini_icons = {}
			end
		end
	end
end

function BlackMarketGui:mws_realign_rcells(panel)
	for _, line in ipairs(panel:children()) do
		if type(line.children) == "function" then
			for _, cell in ipairs(line:children()) do
				if cell:width() == 45 then
					local left = cell:left()
					cell:set_left(left + 5 * (1 + (left - 100 - (left == 190 and 0 or 2)) / 45) + (left == 190 and 2 or 0))
				end
			end
		end
	end
end

function BlackMarketGui:mws_get_bottom(panel)
	local y = 0
	local lines_nr = 0

	for _, line in ipairs(panel:children()) do
		if type(line.bottom) == "function" and line:alpha() > 0 then
			y = math.max(y, line:bottom())
			lines_nr = lines_nr + 1
		end
	end

	return y, lines_nr
end

local mws_original_blackmarketgui_setup = BlackMarketGui._setup
function BlackMarketGui:_setup(...)
	mws_original_blackmarketgui_setup(self, ...)

	self.mws_stats_shown = nil
	local base_panel
	local text_columns = {}

	if self._mweapon_stats_panel and self._tabs[self._selected]._data.identifier == self.identifiers.melee_weapon then
		base_panel = self._mweapon_stats_panel
		self.mws_stats_shown = {
			{ name = "mws_attack_delay" },
			{ name = "mws_cooldown" },
			{ name = "mws_unequip_delay" }
		}
		text_columns = {
			{ size = 100, name = "name" },
			{ size = 55, align = "right", alpha = 0.75, blend = "add", name = "a1" },
			{ size = 88, align = "right", alpha = 0.75, blend = "add", name = "a2" },
		}
	end

	if self._rweapon_stats_panel and self._tabs[self._selected]._data.identifier == self.identifiers.weapon then
		for i, s in pairs(self._stats_shown) do
			if s.name == "reload" then
				local reload_line = self._rweapon_stats_panel:children()[i]
				reload_line:set_alpha(0)
				break
			end
		end

		base_panel = self._rweapon_stats_panel
		self.mws_stats_shown = {
			{ name = "mws_reload_partial", fct = self.mws_reload_partial },
			{ name = "mws_reload_full", fct = self.mws_reload_full },
			{ name = "mws_equip_delay", fct = self.mws_equip_delay },
			{ name = "mws_ammo_pickup", fct = self.mws_ammo_pickup },
		}
		if MoreWeaponStats.settings.show_spread_and_recoil then
			table.insert(self.mws_stats_shown, { name = "mws_recoil_horiz", fct = self.mws_recoil_horiz })
			table.insert(self.mws_stats_shown, { name = "mws_recoil_vert", fct = self.mws_recoil_vert })
			table.insert(self.mws_stats_shown, { name = "mws_accuracy_ads", fct = self.mws_accuracy_ads })
			table.insert(self.mws_stats_shown, { name = "mws_accuracy_crouching", fct = self.mws_accuracy_crouching })
			table.insert(self.mws_stats_shown, { name = "mws_accuracy_standing", fct = self.mws_accuracy_standing })
		end
		table.insert(self.mws_stats_shown, { name = "mws_falloff", fct = self.mws_falloff })
		text_columns = {
			{ size = 100, name = "name" },
			{ size = 50, align = "right", alpha = 0.75, blend = "add", name = "a1" },
			{ size = 50, align = "left", alpha = 0.75, blend = "add", name = "b1" },
			{ size = 50, align = "right", alpha = 0.75, blend = "add", name = "a2" },
			{ size = 50, align = "left", alpha = 0.75, blend = "add", name = "b2" },
		}
	end

	if self.mws_stats_shown then
		local y, lines_nr = self:mws_get_bottom(base_panel)
		local oddeven = math.mod(lines_nr, 2)

		self.mws_stats_texts = {}
		for i, stat in ipairs(self.mws_stats_shown) do
			local panel = base_panel:panel({
				layer = 1,
				x = 0,
				y = y,
				w = base_panel:w(),
				h = 20
			})
			if math.mod(i, 2) == oddeven and not panel:child(tostring(i)) then
				panel:rect({
					color = Color.black:with_alpha(0.3)
				})
			end

			y = y + 20
			local x = 2
			self.mws_stats_texts[stat.name] = {}
			for i, column in ipairs(text_columns) do
				local text_panel = panel:panel({
					layer = 0,
					x = x,
					w = column.size,
					h = panel:h()
				})
				self.mws_stats_texts[stat.name][column.name] = text_panel:text({
					text = i == 1 and managers.localization:to_upper_text(stat.name) or nil,
					font_size = tweak_data.menu.pd2_small_font_size,
					font = tweak_data.menu.pd2_small_font,
					align = column.align,
					layer = 1,
					alpha = column.alpha,
					blend_mode = column.blend,
					color = column.color or tweak_data.screen_colors.text
				})
				x = x + column.size
			end
		end

		self:show_stats()
		self:update_info_text()
	end
end

local mws_original_blackmarketgui_showstats = BlackMarketGui.show_stats
function BlackMarketGui:show_stats()
	mws_original_blackmarketgui_showstats(self)

	if self._mweapon_stats_panel and self._mweapon_stats_panel:visible() then
		if self.mws_stats_texts then
			local melee1 = managers.blackmarket:get_melee_weapon_data(self:mws_get_popup_data(true).name)
			local melee2 = not self._slot_data.equipped and managers.blackmarket:get_melee_weapon_data(self:mws_get_popup_data(false).name)

			-- bits taken from BWS's function InventoryStatsPopup:_melee_weapons_damage()
			for _, stat in ipairs(self.mws_stats_shown) do
				local txt1, txt2
				if stat.name == "mws_attack_delay" then
					txt1 = string.format("%.2fs", melee1.melee_damage_delay or 0)
					txt2 = melee2 and string.format("%.2fs", melee2.melee_damage_delay or 0) or ""
				elseif stat.name == "mws_cooldown" then
					txt1 = string.format("%.2fs", melee1.repeat_expire_t)
					txt2 = melee2 and string.format("%.2fs", melee2.repeat_expire_t) or ""
				elseif stat.name == "mws_unequip_delay" then
					txt1 = string.format("%.2fs", melee1.expire_t)
					txt2 = melee2 and string.format("%.2fs", melee2.expire_t) or ""
				end
				self.mws_stats_texts[stat.name].a1:set_text(txt1)
				self.mws_stats_texts[stat.name].a2:set_text(txt2)
			end
		end
	end

	if self._rweapon_stats_panel and self._rweapon_stats_panel:visible() then
		self:mws_realign_rcells(self._rweapon_stats_panel)
		if self.mws_stats_texts then
			local data1 = self:mws_get_popup_data(true)
			local data2 = not self._slot_data.equipped and self:mws_get_popup_data(false)

			for _, stat in ipairs(self.mws_stats_shown) do
				if stat.fct then
					stat.fct(self, data1, "1", self.mws_stats_texts[stat.name])
					if data2 then
						stat.fct(self, data2, "2", self.mws_stats_texts[stat.name])
					else
						self.mws_stats_texts[stat.name].a2:set_text("")
						self.mws_stats_texts[stat.name].b2:set_text("")
					end
				end
			end

			MoreWeaponStats.mws_slot_data = self._slot_data
		end
	end
end

function BlackMarketGui:mws_get_popup_data(equipped, remove_mod, add_mod, slot_data) -- mostly a copy paste from Better Weapon Stats
	slot_data = slot_data or self._slot_data
	local category = slot_data.category
	local data

	if tweak_data.weapon[slot_data.name] and slot_data.name ~= "sentry_gun" then
		local slot = equipped and managers.blackmarket:equipped_weapon_slot(category) or slot_data.slot
		local weapon = equipped and managers.blackmarket:equipped_item(category) or managers.blackmarket:get_crafted_category_slot(category, slot)
		local name = equipped and weapon.weapon_id or weapon and weapon.weapon_id or slot_data.name
		local factory_id = managers.weapon_factory:get_factory_id_by_weapon_id(name)

		local blueprint = deep_clone(managers.blackmarket:get_weapon_blueprint(category, slot) or managers.weapon_factory:get_default_blueprint_by_factory_id(factory_id))
		if remove_mod and blueprint then
			for i = 1, #blueprint do
				if blueprint[i] == remove_mod then
					table.remove(blueprint, i)
					break
				end
			end
		end
		if add_mod and blueprint then
			table.insert(blueprint, add_mod)
		end

		local ammo_data = factory_id and blueprint and managers.weapon_factory:get_ammo_data_from_weapon(factory_id, blueprint) or {}
		ammo_data.fire_dot_data = tweak_data.weapon[name].fire_dot_data
		local custom_stats = factory_id and blueprint and managers.weapon_factory:get_custom_stats_from_weapon(factory_id, blueprint)
		if custom_stats then
			for part_id, stats in pairs(custom_stats) do
				if tweak_data.weapon.factory.parts[part_id].type ~= "ammo" then
					if stats.ammo_pickup_min_mul then
						ammo_data.ammo_pickup_min_mul = ammo_data.ammo_pickup_min_mul and ammo_data.ammo_pickup_min_mul * stats.ammo_pickup_min_mul or stats.ammo_pickup_min_mul
					end
					if stats.ammo_pickup_max_mul then
						ammo_data.ammo_pickup_max_mul = ammo_data.ammo_pickup_max_mul and ammo_data.ammo_pickup_max_mul * stats.ammo_pickup_max_mul or stats.ammo_pickup_max_mul
					end
				end
				if stats.fire_dot_data then
					ammo_data.fire_dot_data = stats.fire_dot_data
				end
			end
		end
		local base_stats, mods_stats, skill_stats = WeaponDescription._get_stats(name, category, slot, blueprint)
		data = {
			base_stats = base_stats,
			mods_stats = mods_stats,
			skill_stats = skill_stats,
			name = name,
			categories = tweak_data.weapon[name].categories,
			tweak = tweak_data.weapon[name],
			weapon = weapon,
			factory_id = factory_id,
			blueprint = blueprint,
			ammo_data = ammo_data,
			silencer = factory_id and blueprint and managers.weapon_factory:has_perk("silencer", factory_id, blueprint),
			cosmetics = weapon and weapon.cosmetics,
		}
	elseif tweak_data.blackmarket.melee_weapons[slot_data.name] then
		local name = equipped and managers.blackmarket:equipped_item(category) or slot_data.name
		data = {
			name = name,
		}
	end

	return data
end

function BlackMarketGui:mws_get_reload_speed_multiplier(data)
	local fake_weapon_base = MoreWeaponStats.make_newraycastweaponbase(data.factory_id, data.blueprint, data.name)

	local result
	if data.categories[1] == "shotgun" then
		result = RaycastWeaponBase.reload_speed_multiplier(fake_weapon_base)
	elseif data.categories[1] == "bow" and data.tweak.bow_reload_speed_multiplier then
		result = NewRaycastWeaponBase.reload_speed_multiplier(fake_weapon_base) * data.tweak.bow_reload_speed_multiplier
	else
		result = NewRaycastWeaponBase.reload_speed_multiplier(fake_weapon_base)
	end

	return result
end

function BlackMarketGui:mws_reload_full(data, index, txts)
	-- taken from BWS's function InventoryStatsPopup:_primaries_magazine()
	local reload_mul = self:mws_get_reload_speed_multiplier(data)
	local timers = data.tweak.timers
	local reload_not_empty = timers and timers.reload_not_empty
	local reload_empty = timers and timers.reload_empty
	local v

	if reload_not_empty and reload_empty then
		v = reload_empty / reload_mul
	else
		local mag = data.base_stats.magazine.value + data.mods_stats.magazine.value + data.skill_stats.magazine.value
		if timers.shotgun_reload_enter then
			v = (timers.shotgun_reload_enter + timers.shotgun_reload_shell * mag - timers.shotgun_reload_first_shell_offset) / reload_mul
		else
			v = (mag * 17 / 30 - 0.03) / reload_mul
		end
	end

	txts["a" .. index]:set_text(string.format("%.2f%s", v, managers.localization:text("menu_seconds_suffix_short")))
end

function BlackMarketGui:mws_reload_partial(data, index, txts)
	-- taken from BWS's function InventoryStatsPopup:_primaries_magazine()
	local reload_mul = self:mws_get_reload_speed_multiplier(data)
	local timers = data.tweak.timers
	local reload_not_empty = timers and timers.reload_not_empty
	local reload_empty = timers and timers.reload_empty
	local s = managers.localization:text("menu_seconds_suffix_short")

	if reload_not_empty and reload_empty then
		txts["a" .. index]:set_text(string.format("%.2f%s", reload_not_empty / reload_mul, s))
		txts["b" .. index]:set_text("")
	else
		local time_first_shell, time_additional_shell
		if timers.shotgun_reload_enter then
			time_first_shell = (timers.shotgun_reload_enter + timers.shotgun_reload_shell - timers.shotgun_reload_first_shell_offset) / reload_mul
			time_additional_shell = timers.shotgun_reload_shell / reload_mul
		else
			time_first_shell = (17 / 30 - 0.03) / reload_mul
			time_additional_shell = 17 / 30 / reload_mul
		end
		txts["a" .. index]:set_text(string.format("%.2f%s", time_first_shell, s))
		txts["b" .. index]:set_text(string.format(" | %.2f%s", time_additional_shell, s))
	end
end

function BlackMarketGui:mws_ammo_pickup(data, index, txts)
	-- taken from BWS's function InventoryStatsPopup:_primaries_totalammo()
	local pickup = data.tweak.AMMO_PICKUP
	if pickup[1] == 0 and pickup[2] == 0 then
		txts["a" .. index]:set_text("")
		txts["b" .. index]:set_text("")
	else
		local ammo_data = data.ammo_data
		local skill_pickup = 1 + managers.player:upgrade_value("player", "pick_up_ammo_multiplier", 1) + managers.player:upgrade_value("player", "pick_up_ammo_multiplier_2", 1) - 2
		local ammo_pickup_min_mul = ammo_data and ammo_data.ammo_pickup_min_mul or skill_pickup
		local ammo_pickup_max_mul = ammo_data and ammo_data.ammo_pickup_max_mul or skill_pickup
		txts["a" .. index]:set_text(string.format("%.2f", pickup[1] * ammo_pickup_min_mul))
		txts["b" .. index]:set_text(string.format(" | %.2f", pickup[2] * ammo_pickup_max_mul))
	end
end

function BlackMarketGui:mws_falloff(data, index, txts)
	-- taken from BWS's function InventoryStatsPopup:_primaries_damage()
	if data.tweak.categories[1] ~= "shotgun" then
		txts["a" .. index]:set_text("")
		txts["b" .. index]:set_text("")
	else
		local ammo_data = data.ammo_data
		local near = data.tweak.damage_near / 100
		local far = data.tweak.damage_far / 100
		local near_mul = ammo_data and ammo_data.damage_near_mul or 1
		local far_mul = ammo_data and ammo_data.damage_far_mul or 1
		txts["a" .. index]:set_text(string.format("%.1fm", near * near_mul))
		txts["b" .. index]:set_text(string.format(" | %.1fm", near * near_mul + far * far_mul))
	end
end

function MoreWeaponStats.get_current_stats(data)
	-- comes from function NewRaycastWeaponBase:_update_stats_values()
	local stats = deep_clone(data.tweak.stats)

	local parts_stats = managers.weapon_factory:get_stats(data.factory_id, data.blueprint)
	local stats_tweak_data = tweak_data.weapon.stats

	local bonus = data.cosmetics and data.cosmetics.id and tweak_data.blackmarket.weapon_skins[data.cosmetics.id] and tweak_data.blackmarket.weapon_skins[data.cosmetics.id].bonus
	local bonus_stats = bonus and tweak_data.economy.bonuses[bonus] and tweak_data.economy.bonuses[bonus].stats or {}

	for stat, _ in pairs(stats) do
		if parts_stats[stat] then
			stats[stat] = stats[stat] + parts_stats[stat]
		end
		if bonus_stats[stat] then
			stats[stat] = stats[stat] + bonus_stats[stat]
		end
		stats[stat] = math.clamp(stats[stat], 1, #stats_tweak_data[stat])
	end
	local result = { indices = stats }

	local modifier_stats = data.tweak.stats_modifiers
	local _current_stats = {}
	for stat, i in pairs(stats) do
		_current_stats[stat] = stats_tweak_data[stat] and stats_tweak_data[stat][i] or 1
		if modifier_stats and modifier_stats[stat] then
			_current_stats[stat] = _current_stats[stat] * modifier_stats[stat]
		end
	end
	result.values = _current_stats

	return result
end

function MoreWeaponStats.make_state(st_moving, st_ducking, st_deploy, st_steelsight)
	return {
		_moving = st_moving,
		_steelsight = st_steelsight,
		_unit_deploy_position = st_deploy,
		_state_data = { ducking = st_ducking },
		in_steelsight = function(self)
			return self._steelsight
		end,
		get_movement_state = PlayerStandard.get_movement_state
	}
end

function MoreWeaponStats.make_user_unit(st_moving, st_ducking, st_deploy, st_steelsight)
	return {
		_movement = {
			_current_state = MoreWeaponStats.make_state(st_moving, st_ducking, st_deploy, st_steelsight)
		},
		movement = function(self)
			return self._movement
		end
	}
end

function MoreWeaponStats.make_newraycastweaponbase(factory_id, blueprint, name_id)
	local result = {}
	for k, v in pairs(RaycastWeaponBase) do
		result[k] = v
	end
	for k, v in pairs(NewRaycastWeaponBase) do
		result[k] = v
	end
	result._name_id = name_id
	result._factory_id = factory_id
	result._blueprint = blueprint
	result._sound_fire = {
		set_switch = function() end
	}
	result._muzzle_effect_table = {}
	result._parts = {}
	if MoreWeaponStats_update_stats_values then
		MoreWeaponStats_update_stats_values(result)
	else
		NewRaycastWeaponBase._update_stats_values(result)
	end
	return result
end

function MoreWeaponStats.make_playerstate(factory_id, blueprint, name_id)
	local wb = MoreWeaponStats.make_newraycastweaponbase(factory_id, blueprint, name_id)
	return {
		_equipped_unit = {
			base = function()
				return wb
			end
		}
	}
end

function MoreWeaponStats.mws_get_spread(data, st_moving, st_ducking, st_deploy, st_steelsight)
	local tmp = NewRaycastWeaponBase.replenish
	NewRaycastWeaponBase.replenish = function() end
	local fake_weapon_base = MoreWeaponStats.make_newraycastweaponbase(data.factory_id, data.blueprint, data.name)
	local fake_user_unit = MoreWeaponStats.make_user_unit(st_moving, st_ducking, st_deploy, st_steelsight)
	local spread_x, spread_y = NewRaycastWeaponBase._get_spread(fake_weapon_base, fake_user_unit)
	NewRaycastWeaponBase.replenish = tmp
	return spread_x
end

function BlackMarketGui:mws_accuracy(data, index, txts, st_ducking, st_deploy, st_steelsight)
	if data.tweak.categories[1] == "saw" then
		txts["a" .. index]:set_text("")
		txts["b" .. index]:set_text("")
	else
		txts["a" .. index]:set_text(string.format("%.2f'", MoreWeaponStats.mws_get_spread(data, false, st_ducking, st_deploy, st_steelsight)))
		txts["b" .. index]:set_text(string.format(" | %.2f'", MoreWeaponStats.mws_get_spread(data, true, st_ducking, st_deploy, st_steelsight)))
	end
end

function BlackMarketGui:mws_accuracy_ads(data, index, txts)
	self:mws_accuracy(data, index, txts, false, false, true)
end

function BlackMarketGui:mws_accuracy_standing(data, index, txts)
	self:mws_accuracy(data, index, txts, false, false, false)
end

function BlackMarketGui:mws_accuracy_crouching(data, index, txts)
	self:mws_accuracy(data, index, txts, true, false, false)
end

function MoreWeaponStats.mws_get_recoil(data, current_stats, st_ducking, st_steelsight)
	-- comes from function PlayerStandard:_check_action_primary_attack()
	local current_state = MoreWeaponStats.make_state(st_moving, st_ducking, st_deploy, st_steelsight)

	local recoil = current_stats.values.recoil
	local recoil_addend = managers.blackmarket:recoil_addend(data.name, data.tweak.categories, current_stats.indices and current_stats.indices.recoil, data.silencer, data.blueprint)
	local recoil_base_multiplier = managers.blackmarket:recoil_multiplier(data.name, data.tweak.categories, data.silencer, data.blueprint)
	local recoil_multiplier = (recoil + recoil_addend) * recoil_base_multiplier

	local up, down, left, right = unpack(data.tweak.kick[st_steelsight and "steelsight" or st_ducking and "crouching" or "standing"])
	return {
		up = up * recoil_multiplier,
		down = down * recoil_multiplier,
		left = left * recoil_multiplier,
		right = right * recoil_multiplier
	}
end

function BlackMarketGui:mws_recoil_horiz(data, index, txts)
	local current_stats = MoreWeaponStats.get_current_stats(data)
	local recoil = MoreWeaponStats.mws_get_recoil(data, current_stats, false, false)
	txts["a" .. index]:set_text(string.format("%.2f'", recoil.left))
	txts["b" .. index]:set_text(string.format(" | %.2f'", recoil.right))
end

function BlackMarketGui:mws_recoil_vert(data, index, txts)
	local current_stats = MoreWeaponStats.get_current_stats(data)
	local recoil = MoreWeaponStats.mws_get_recoil(data, current_stats, false, false)
	txts["a" .. index]:set_text(string.format("%.2f'", recoil.up))
	txts["b" .. index]:set_text(string.format(" | %.2f'", recoil.down))
end

function MoreWeaponStats.mws_get_swap_speed(data)
	local fake_player_state = MoreWeaponStats.make_playerstate(data.factory_id, data.blueprint, data.name)
	local divider = PlayerStandard._get_swap_speed_multiplier(fake_player_state)

	-- 0.7 found in PlayerStandard:_start_action_equip_weapon()
	-- 0.5 found in PlayerStandard:_start_action_unequip_weapon()
	return {
		equip = (data.tweak.timers.equip or 0.7) / divider,
		unequip = (data.tweak.timers.unequip or 0.5) / divider
	}
end

function BlackMarketGui:mws_equip_delay(data, index, txts)
	local swap_delays = MoreWeaponStats.mws_get_swap_speed(data)
	txts["a" .. index]:set_text(string.format("%.2fs", swap_delays.equip))
	txts["b" .. index]:set_text(string.format(" | %.2fs", swap_delays.unequip))
end
