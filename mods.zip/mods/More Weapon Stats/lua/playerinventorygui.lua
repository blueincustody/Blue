local mws_original_playerinventorygui_startcraftingweapon = PlayerInventoryGui._start_crafting_weapon
function PlayerInventoryGui:_start_crafting_weapon(data, new_node_data)
	MoreWeaponStats.mws_slot_data = data
	mws_original_playerinventorygui_startcraftingweapon(self, data, new_node_data)
end

