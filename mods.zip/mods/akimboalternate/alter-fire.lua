local old_akimbo_fire_toggle=AkimboWeaponBase.toggle_firemode

function AkimboWeaponBase:toggle_firemode()
    
    if tweak_data.weapon[self:get_name_id()].categories[2]=="pistol" then
        self._manual_fire_second_gun=not self._manual_fire_second_gun
        return false
    else 
        return old_akimbo_fire_toggle(self)
    end
    
end
    
    
    
   