local old_akimbo_fire_toggle=AkimboWeaponBase.toggle_firemode

function AkimboWeaponBase:toggle_firemode()
    
    local wep = false;
    
    local autoakimbo={"x_akmsu","x_mp5","x_sr2"}
    for i=1,table.getn(autoakimbo) do
        if self:get_name_id() == autoakimbo[i]
            then 
            wep= true
            break
        end
    end
    if wep then
        return old_akimbo_fire_toggle(self)
    else 
        self._manual_fire_second_gun=not self._manual_fire_second_gun
    end
    
end
    
    
    