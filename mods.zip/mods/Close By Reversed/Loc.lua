local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_close_by_beta_desc" and "BASIC: ##3 points##\nYour rate of fire is increased by ##35%## while firing from the hip with single shot Shotguns. Shotguns with magazines have their magazine sizes increased by ##15## shells.\n\nACE: ##6 points##\nYou can now hip-fire with your Shotguns while sprinting"
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end