local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.close_by = {
		["name_id"] = "menu_close_by_beta",
		["desc_id"] = "menu_close_by_beta_desc",
		["icon_xy"] = {8, 6},
		[1] = {
			upgrades = {
				"shotgun_hip_run_and_shoot_1",
				"shotgun_hip_rate_of_fire_1",
				"shotgun_magazine_capacity_inc_1"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {
				"shotgun_hip_run_and_shoot_1",
				"shotgun_hip_rate_of_fire_1",
				"shotgun_magazine_capacity_inc_1"
			},
			cost = self.costs.hightierpro
		}
	}
end	