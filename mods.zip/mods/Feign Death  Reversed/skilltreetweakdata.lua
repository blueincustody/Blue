local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.feign_death = {
		["name_id"] = "menu_feign_death",
		["desc_id"] = "menu_feign_death_desc",
		["icon_xy"] = {11, 5},
		[1] = {
			upgrades = {
			"player_cheat_death_chance_2"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {
			"player_cheat_death_chance_2"
			},
			cost = self.costs.hightierpro
		}
	}
end	