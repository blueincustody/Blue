local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_feign_death_beta_desc" and "BASIC: ##3 points##\nWhen you get downed, you have a ##15%## chance to instantly get revived.\n\nACE: ##6 points##\nThe chance to get revived is increased by an additional ##30%##."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end