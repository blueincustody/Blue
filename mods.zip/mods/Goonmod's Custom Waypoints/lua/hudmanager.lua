local gcw_original_hudmanager_save = HUDManager.save
function HUDManager:save(data)
	gcw_original_hudmanager_save(self, data)

	local remove_list = {}
	for id, _ in pairs(data.HUDManager.waypoints) do
		if type(id) == 'string' and id:find(CustomWaypoints.prefix) == 1 then
			remove_list[id] = true
		end
	end

	for id in pairs(remove_list) do
		data.HUDManager.waypoints[id] = nil
	end
end
