local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.dance_instructor = {
		["name_id"] = "menu_dance_instructor",
		["desc_id"] = "menu_dance_instructor_desc",
		["icon_xy"] = {11, 0},
		[1] = {
			upgrades = {
				"pistol_fire_rate_multiplier"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {
				"pistol_fire_rate_multiplier"
			},
			cost = self.costs.hightierpro
			}
		}
end	