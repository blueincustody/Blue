local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_dance_instructor_beta_desc" and "BASIC: ##2 points##\nYou gain a ##50%## increased rate of fire with pistols.\n\nACE: ##4 points##\nYour pistol magazine sizes are increased by ##5## bullets."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end