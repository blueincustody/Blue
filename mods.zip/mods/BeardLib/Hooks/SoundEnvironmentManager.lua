function CoreSoundEnvironmentManager:emitter_events(path)
	return {""}
end

function CoreSoundEnvironmentManager:ambience_events()
	return {""}
end