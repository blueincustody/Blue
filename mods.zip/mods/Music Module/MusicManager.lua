local debug = false
function log_music(msg, force)
	if debug or force then
		log("[Music Module] " .. tostring(msg))
	end
end

Hooks:PostHook(MusicManager, "init", "BeardLibMusicManagerInit", function(self)
	for _, music in pairs(BeardLib._music) do
		if music.heist then
			table.insert(tweak_data.music.track_list, {track = music.id})
		end
		if music.menu then
			table.insert(tweak_data.music.track_menu_list, {track = music.id})
		end
	end
end)

Hooks:PostHook(MusicManager, "load_settings", "BeardLibMusicManagerLoadSettings", function(self)
	self:check_playlist()
end)

function MusicManager:check_playlist(is_menu)
    local playlist = is_menu and self:playlist_menu() or self:playlist()
    local tracklist = is_menu and tweak_data.music.track_menu_list or tweak_data.music.track_list
    for i, track in pairs(playlist) do
        local exists
        for _, v in pairs(tracklist) do
            if v.track == track then
                exists = true
            end
        end
        if not exists then
            log_music("Removing unloaded music from playlist..", true)
            playlist[i] = nil
            managers.savefile:setting_changed()
        end
    end
    if not is_menu then
        self:check_playlist(true)
    end
end

function MusicManager:stop_custom()
	if alive(self._player) then
		self._player:parent():remove(self._player)
	end
end

function CoreMusicManager:post_event(name)
	log_music("post event")
	if not name then 
		return
	end
	if Global.music_manager.current_event ~= name then
		if not self._skip_play then
			if not self:attempt_play(nil, name, true) then 
				Global.music_manager.source:post_event(name)
			else
				log_music("attempt successful #5")	
			end
		end
		Global.music_manager.current_event = name
	end
end

function MusicManager:track_listen_start(event, track)
	log_music("listen start")
	if self._current_track == track and self._current_event == event then
		return
	end
	self._skip_play = true
	Global.music_manager.source:stop()
	self:stop_custom()
	if track then
		if not self:attempt_play(track) then  		
			Global.music_manager.source:set_switch("music_randomizer", track)
		else
			log_music("attempt successful #3")			
		end
	end
	if not self:attempt_play(nil, event) then 
		Global.music_manager.source:post_event(event)
	else
		log_music("attempt successful #4")		
	end
	self._current_track = track
	self._current_event = event
end

function MusicManager:check_music_switch()
	log_music("check music switch")
	local switches = tweak_data.levels:get_music_switches()
	if switches and #switches > 0 then
		Global.music_manager.current_track = switches[math.random(#switches)]
		if not self:attempt_play(Global.music_manager.current_track) then  		
			Global.music_manager.source:set_switch("music_randomizer", Global.music_manager.current_track)
		else
			log_music("attempt successful #2")
		end
	end
end

function MusicManager:track_listen_stop()
	log_music("stop listen")
	if self._current_event then
		self:stop_custom()
		Global.music_manager.source:post_event("stop_all_music")
		if Global.music_manager.current_event then
			if not self:attempt_play(nil, Global.music_manager.current_event) then
				Global.music_manager.source:post_event(Global.music_manager.current_event)
			else
				log_music("attempt successful")
			end
		end
	end
	if self._current_track and Global.music_manager.current_track then
		if not self:attempt_play(Global.music_manager.current_track) then
			Global.music_manager.source:set_switch("music_randomizer", Global.music_manager.current_track)
		else
			log_music("attempt successful .")		
		end
	end
	self._current_event = nil
	self._current_track = nil
	--self._current_custom_track = nil
	self._skip_play = nil
end 

function MusicManager:attempt_play(track, event, stop)
	log_music("attempting to play " .. tostring( track ) .. " , " .. tostring( event ))
	if stop then
		self:stop_custom()
	end
	local source 
	local start_source
	if track and track ~= self._current_custom_track then
		log_music("CURRENT CUSTOM TRACK IS NIL")
		self._current_custom_track = nil
	end
	for _, sound in pairs(BeardLib._music) do
		if source then
			break
		end 
		if sound.id == track or sound.id == event then
			if self._current_custom_track ~= sound.id or sound.id == event then
				source = sound.source
				self._current_custom_track = sound.id
			else
				log_music("Attempting to play a track that is already playing?", true)
			end
		end
		if event and self._current_custom_track == sound.id then
			for k,v in pairs(sound) do
				local short_event = string.split(event, "_")[3]
				if type(v) == "table" and v._meta == "event" and v.name == short_event then
					start_source = type(v.start_source) == "string" and DB:has(Idstring("movie"), v.start_source) and v.start_source
					source = v.source
				end
			end
		end
	end	
	if source then
		if DB:has(Idstring("movie"), source) and managers.menu_component._main_panel then
			self._switch_at_end = start_source and source
			self:play(start_source or source)
		else
			log_music(string.format("[ERROR] Trying to play from unloaded source '%s'", tostring(source)), true)
		end		
	else
		log_music(string.format("Didn't find any source for track %s and event %s current custom track is %s", tostring(track), tostring(event), tostring(self._current_custom_track)), true)
	end
	return source ~= nil
end

function MusicManager:play(src)
	self:stop_custom()
	Global.music_manager.source:post_event("stop_all_music")
    self._player = managers.menu_component._main_panel:video({
        name = "music",
        video = src,
        visible = false,
        loop = not self._switch_at_end,
    })   
 	self._player:set_volume_gain(Global.music_manager.volume)
end 

Hooks:PostHook(MusicManager, "set_volume", "BeardLibMusicManagerSetVolume", function(self, volume)
	if alive(self._player) then
		self._player:set_volume_gain(volume)
	end	
end)

Hooks:Add("GameSetupUpdate", "BeardLibMusicUpdate", function()
	local music = managers.music
	if music and alive(music._player) then
	 	music._player:set_volume_gain(Global.music_manager.volume)
        if music._switch_at_end and (music._player:current_frame() >= music._player:frames()) then
            log_music("finished playing starting music...switching.")
            music:play(music._switch_at_end)
        end
	end
end)

Hooks:Add("GameSetupPauseUpdate", "BeardLibMusicPausedUpdate", function()
	local music = managers.music
	if music and alive(music._player) then
	 	music._player:set_volume_gain(0)
		music._player:goto_frame(music._player:current_frame()) --Force because the pause function is kinda broken :/
	end
end)