if RequiredScript == "lib/entry" then
	ModCore:new(ModPath .. "Config.xml", true, true)
elseif RequiredScript == "core/lib/system/coresystem" then
	BeardLib._music = {}
	local Path = ModPath
	Hooks:PostHook(BeardLib, "LoadModules", "LoadMusicModule", function()
		dofile(Path .. "MusicModule.lua")
	end)
end