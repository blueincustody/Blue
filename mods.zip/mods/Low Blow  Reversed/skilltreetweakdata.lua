local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.backstab = {
		["name_id"] = "menu_backstab_beta",
		["desc_id"] = "menu_backstab_beta_desc",
		["icon_xy"] = {0, 12},
		[1] = {
			upgrades = {
				"player_detection_risk_add_crit_chance_2"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {
				"player_detection_risk_add_crit_chance_2"
			},
			cost = self.costs.hightierpro
		}
	}
end	