local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_backstab_beta_desc" and "BASIC: ##3 points##\nYou gain a ##3%## critical hit chance for every ##3## point of concealment under 35 up to a maximum of ##30%##\n\nACE: ##6 points##\nYou gain a ##3%## critical hit chance for every ##1## point of concealment under ##35## up to a maximum of ##30%##\nNote: Does not apply to grenade launchers."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end