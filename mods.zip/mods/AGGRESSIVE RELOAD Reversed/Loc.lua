local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_speedy_reload_beta_desc" and "BASIC: ##3 points##\nIncreases your reload speed with assault rifles by ##15%##. \n\nACE: ##6 points##\nAny killing headshot will reduce your reload time by ##40%## for ##2## seconds. Can only be triggered by SMGs, Assault Rifles and Sniper Rifles fired in single shot fire mode."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end