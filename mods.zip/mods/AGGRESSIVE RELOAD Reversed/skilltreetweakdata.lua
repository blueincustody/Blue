local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.speedy_reload = {
		["name_id"] = "menu_speedy_reload_beta",
		["desc_id"] = "menu_speedy_reload_beta_desc",
		["icon_xy"] = {8, 3},
		[1] = {
			upgrades = {
				"assault_rifle_reload_speed_multiplier",
				"smg_reload_speed_multiplier",
				"snp_reload_speed_multiplier",
				"temporary_single_shot_fast_reload_1"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {
				"assault_rifle_reload_speed_multiplier",
				"smg_reload_speed_multiplier",
				"snp_reload_speed_multiplier",
				"temporary_single_shot_fast_reload_1"
			},
			cost = self.costs.hightierpro
		}
	}
end	