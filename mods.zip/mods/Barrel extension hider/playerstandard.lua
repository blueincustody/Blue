function PlayerStandard:_start_action_melee(t, input, instant)
	self._equipped_unit:base():tweak_data_anim_stop("fire")
	self:_interupt_action_reload(t)
	self:_interupt_action_steelsight(t)
	self:_interupt_action_running(t)
	self:_interupt_action_charging_weapon(t)
	self._state_data.melee_charge_wanted = nil
	self._state_data.meleeing = true
	self._state_data.melee_start_t = nil
	local melee_entry = managers.blackmarket:equipped_melee_weapon()
	local primary = managers.blackmarket:equipped_primary()
	local primary_id = primary.weapon_id
	local secondary_id = secondary.weapon_id
	local bayonet_id = managers.blackmarket:equipped_bayonet(primary_id) or managers.blackmarket:equipped_bayonet(secondary_id)
	local bayonet_melee = false
	if bayonet_id and melee_entry == "weapon" and self._equipped_unit:base():selection_index() == 2 then
		bayonet_melee = true
	end
	if instant then
		self:_do_action_melee(t, input)
		return
	end
	self:_stance_entered()
	if self._state_data.melee_global_value then
		self._camera_unit:anim_state_machine():set_global(self._state_data.melee_global_value, 0)
	end
	local melee_entry = managers.blackmarket:equipped_melee_weapon()
	self._state_data.melee_global_value = tweak_data.blackmarket.melee_weapons[melee_entry].anim_global_param
	self._camera_unit:anim_state_machine():set_global(self._state_data.melee_global_value, 1)
	local current_state_name = self._camera_unit:anim_state_machine():segment_state(PlayerStandard.IDS_BASE)
	local attack_allowed_expire_t = tweak_data.blackmarket.melee_weapons[melee_entry].attack_allowed_expire_t or 0.15
	self._state_data.melee_attack_allowed_t = t + (current_state_name ~= PlayerStandard.IDS_MELEE_ATTACK_STATE and attack_allowed_expire_t or 0)
	if current_state_name == PlayerStandard.IDS_MELEE_ATTACK_STATE then
		self._ext_camera:play_redirect(PlayerStandard.IDS_MELEE_CHARGE)
		return
	end
	local offset
	if current_state_name == PlayerStandard.IDS_MELEE_EXIT_STATE then
		local segment_relative_time = self._camera_unit:anim_state_machine():segment_relative_time(PlayerStandard.IDS_BASE)
		offset = (1 - segment_relative_time) * 0.9
	end
	self._ext_camera:play_redirect(PlayerStandard.IDS_MELEE_ENTER, nil, offset)
end