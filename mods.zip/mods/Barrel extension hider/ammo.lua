CloneClass(WeaponFactoryTweakData)
--pistols
function WeaponFactoryTweakData._init_deagle(self)
self.orig._init_deagle(self)
table.insert(self.wpn_fps_pis_deagle.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_g18c(self)
self.orig._init_g18c(self)
table.insert(self.wpn_fps_pis_g18c.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_colt_1911(self)
self.orig._init_colt_1911(self)
table.insert(self.wpn_fps_pis_1911.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_g17(self)
self.orig._init_g17(self)
table.insert(self.wpn_fps_pis_g17.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_b92fs(self)
self.orig._init_b92fs(self)
table.insert(self.wpn_fps_pis_beretta.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_raging_bull(self)
self.orig._init_raging_bull(self)
table.insert(self.wpn_fps_pis_rage.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_usp(self)
self.orig._init_usp(self)
table.insert(self.wpn_fps_pis_usp.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_g22c(self)
self.orig._init_g22c(self)
table.insert(self.wpn_fps_pis_g22c.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_ppk(self)
self.orig._init_ppk(self)
table.insert(self.wpn_fps_pis_ppk.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_p226(self)
self.orig._init_p226(self)
table.insert(self.wpn_fps_pis_p226.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_g26(self)
self.orig._init_g26(self)
table.insert(self.wpn_fps_pis_g26.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_c96(self)
self.orig._init_c96(self)
table.insert(self.wpn_fps_pis_c96.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_hs2000(self)
self.orig._init_hs2000(self)
table.insert(self.wpn_fps_pis_hs2000.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_peacemaker(self)
self.orig._init_peacemaker(self)
table.insert(self.wpn_fps_pis_peacemaker.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_mateba(self)
self.orig._init_mateba(self)
table.insert(self.wpn_fps_pis_2006m.uses_parts, "wpn_fps_upg_hidebarrelext")
end

--snp
function WeaponFactoryTweakData._init_wa2000(self)
self.orig._init_wa2000(self)
table.insert(self.wpn_fps_snp_wa2000.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_winchester1874(self)
self.orig._init_winchester1874(self)
table.insert(self.wpn_fps_snp_winchester.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_mosin(self)
self.orig._init_mosin(self)
table.insert(self.wpn_fps_snp_mosin.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_m95(self)
self.orig._init_m95(self)
table.insert(self.wpn_fps_snp_m95.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_msr(self)
self.orig._init_msr(self)
table.insert(self.wpn_fps_snp_msr.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_r93(self)
self.orig._init_r93(self)
table.insert(self.wpn_fps_snp_r93.uses_parts, "wpn_fps_upg_hidebarrelext")
end

--lmg
function WeaponFactoryTweakData._init_par(self)
self.orig._init_par(self)
table.insert(self.wpn_fps_lmg_par.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_m134(self)
self.orig._init_m134(self)
table.insert(self.wpn_fps_lmg_m134.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_mg42(self)
self.orig._init_mg42(self)
table.insert(self.wpn_fps_lmg_mg42.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_hk21(self)
self.orig._init_hk21(self)
table.insert(self.wpn_fps_lmg_hk21.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_m249(self)
self.orig._init_m249(self)
table.insert(self.wpn_fps_lmg_m249.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_rpk(self)
self.orig._init_rpk(self)
table.insert(self.wpn_fps_lmg_rpk.uses_parts, "wpn_fps_upg_hidebarrelext")
end

--smg
function WeaponFactoryTweakData._init_polymer(self)
self.orig._init_polymer(self)
table.insert(self.wpn_fps_smg_polymer.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_baka(self)
self.orig._init_baka(self)
table.insert(self.wpn_fps_smg_baka.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_olympic(self)
self.orig._init_olympic(self)
table.insert(self.wpn_fps_smg_olympic.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_cobray(self)
self.orig._init_cobray(self)
table.insert(self.wpn_fps_smg_cobray.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_akmsu(self)
self.orig._init_akmsu(self)
table.insert(self.wpn_fps_smg_akmsu.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_sterling(self)
self.orig._init_sterling(self)
table.insert(self.wpn_fps_smg_sterling.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_scorpion(self)
self.orig._init_scorpion(self)
table.insert(self.wpn_fps_smg_scorpion.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_mp7(self)
self.orig._init_mp7(self)
table.insert(self.wpn_fps_smg_mp7.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_m45(self)
self.orig._init_m45(self)
table.insert(self.wpn_fps_smg_m45.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_mac10(self)
self.orig._init_mac10(self)
table.insert(self.wpn_fps_smg_mac10.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_mp9(self)
self.orig._init_mp9(self)
table.insert(self.wpn_fps_smg_mp9.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_p90(self)
self.orig._init_p90(self)
table.insert(self.wpn_fps_smg_p90.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_mp5(self)
self.orig._init_mp5(self)
table.insert(self.wpn_fps_smg_mp5.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_tec9(self)
self.orig._init_tec9(self)
table.insert(self.wpn_fps_smg_tec9.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_uzi(self)
self.orig._init_uzi(self)
table.insert(self.wpn_fps_smg_uzi.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_m1928(self)
self.orig._init_m1928(self)
table.insert(self.wpn_fps_smg_thompson.uses_parts, "wpn_fps_upg_hidebarrelext")
end

--shotguns
function WeaponFactoryTweakData._init_judge(self)
self.orig._init_judge(self)
table.insert(self.wpn_fps_pis_judge.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_saiga(self)
self.orig._init_saiga(self)
table.insert(self.wpn_fps_shot_saiga.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_r870(self)
self.orig._init_r870(self)
table.insert(self.wpn_fps_shot_r870.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_huntsman(self)
self.orig._init_huntsman(self)
table.insert(self.wpn_fps_shot_huntsman.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_serbu(self)
self.orig._init_serbu(self)
table.insert(self.wpn_fps_shot_serbu.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_ben(self)
self.orig._init_ben(self)
table.insert(self.wpn_fps_sho_ben.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_striker(self)
self.orig._init_striker(self)
table.insert(self.wpn_fps_sho_striker.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_ksg(self)
self.orig._init_ksg(self)
table.insert(self.wpn_fps_sho_ksg.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_spas12(self)
self.orig._init_spas12(self)
table.insert(self.wpn_fps_sho_spas12.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_b682(self)
self.orig._init_b682(self)
table.insert(self.wpn_fps_shot_b682.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_aa12(self)
self.orig._init_aa12(self)
table.insert(self.wpn_fps_sho_aa12.uses_parts, "wpn_fps_upg_hidebarrelext")
end

--akimbo
function WeaponFactoryTweakData._init_x_g22c(self)
self.orig._init_x_g22c(self)
table.insert(self.wpn_fps_pis_x_g22c.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_g17(self)
self.orig._init_x_g17(self)
table.insert(self.wpn_fps_pis_x_g17.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_usp(self)
self.orig._init_x_usp(self)
table.insert(self.wpn_fps_pis_x_usp.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_jowi(self)
self.orig._init_jowi(self)
table.insert(self.wpn_fps_jowi.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_1911(self)
self.orig._init_x_1911(self)
table.insert(self.wpn_fps_x_1911.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_b92fs(self)
self.orig._init_x_b92fs(self)
table.insert(self.wpn_fps_x_b92fs.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_deagle(self)
self.orig._init_x_deagle(self)
table.insert(self.wpn_fps_x_deagle.uses_parts, "wpn_fps_upg_hidebarrelext")
end

--assault rifles
function WeaponFactoryTweakData._init_m4(self)
self.orig._init_m4(self)
table.insert(self.wpn_fps_ass_m4.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_amcar(self)
self.orig._init_amcar(self)
table.insert(self.wpn_fps_ass_amcar.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_m16(self)
self.orig._init_m16(self)
table.insert(self.wpn_fps_ass_m16.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_ak74(self)
self.orig._init_ak74(self)
table.insert(self.wpn_fps_ass_74.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_akm(self)
self.orig._init_akm(self)
table.insert(self.wpn_fps_ass_akm.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_akm_gold(self)
self.orig._init_akm_gold(self)
table.insert(self.wpn_fps_ass_akm_gold.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_ak5(self)
self.orig._init_ak5(self)
table.insert(self.wpn_fps_ass_ak5.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_aug(self)
self.orig._init_aug(self)
table.insert(self.wpn_fps_ass_aug.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_g36(self)
self.orig._init_g36(self)
table.insert(self.wpn_fps_ass_g36.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_m14(self)
self.orig._init_m14(self)
table.insert(self.wpn_fps_ass_m14.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_s552(self)
self.orig._init_s552(self)
table.insert(self.wpn_fps_ass_s552.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_scar(self)
self.orig._init_scar(self)
table.insert(self.wpn_fps_ass_scar.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_fal(self)
self.orig._init_fal(self)
table.insert(self.wpn_fps_ass_fal.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_g3(self)
self.orig._init_g3(self)
table.insert(self.wpn_fps_ass_g3.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_galil(self)
self.orig._init_galil(self)
table.insert(self.wpn_fps_ass_galil.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_famas(self)
self.orig._init_famas(self)
table.insert(self.wpn_fps_ass_famas.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_l85a2(self)
self.orig._init_l85a2(self)
table.insert(self.wpn_fps_ass_l85a2.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_vhs(self)
self.orig._init_vhs(self)
table.insert(self.wpn_fps_ass_vhs.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_asval(self)
self.orig._init_asval(self)
table.insert(self.wpn_fps_ass_asval.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_sub2000(self)
self.orig._init_sub2000(self)
table.insert(self.wpn_fps_ass_sub2000.uses_parts, "wpn_fps_upg_hidebarrelext")
end

function WeaponFactoryTweakData._init_model70(self)
self.orig._init_model70(self)
table.insert(self.wpn_fps_snp_model70.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_sparrow(self)
self.orig._init_sparrow(self)
table.insert(self.wpn_fps_pis_sparrow.uses_parts, "wpn_fps_upg_hidebarrelext")
end


function WeaponFactoryTweakData._init_m37(self)
self.orig._init_m37(self)
table.insert(self.wpn_fps_shot_m37.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_sr2(self)
self.orig._init_sr2(self)
table.insert(self.wpn_fps_smg_sr2.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_sr2(self)
self.orig._init_x_sr2(self)
table.insert(self.wpn_fps_smg_x_sr2.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_pl14(self)
self.orig._init_pl14(self)
table.insert(self.wpn_fps_pis_pl14.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_mp5(self)
self.orig._init_x_mp5(self)
table.insert(self.wpn_fps_smg_x_mp5.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_x_akmsu(self)
self.orig._init_x_akmsu(self)
table.insert(self.wpn_fps_smg_x_akmsu.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_tecci(self)
self.orig._init_tecci(self)
table.insert(self.wpn_fps_ass_tecci.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_hajk(self)
self.orig._init_hajk(self)
table.insert(self.wpn_fps_smg_hajk.uses_parts, "wpn_fps_upg_hidebarrelext")
end
function WeaponFactoryTweakData._init_boot(self)
self.orig._init_boot(self)
table.insert(self.wpn_fps_sho_boot.uses_parts, "wpn_fps_upg_hidebarrelext")
end










