Hooks:Add("NetworkReceivedData", "NetworkReceivedData_barrelhider", function(peer_id, id, data)
	if id == "barrelhiderModPeer" and data == "V1" then
		managers.network:session():peer(peer_id):set_has_barrelhider(true)
		LuaNetworking:SendToPeers( "barrelhiderModPeerReply", "V1" )
		managers.network:session():check_send_outfit(nil, true)
		log("has barrelhider")
	end
	if id == "barrelhiderModPeerReply" and data == "V1" then
		managers.network:session():peer(peer_id):set_has_barrelhider(true)
		log("has barrelhider")
	end
	if string.match(id, "%w+") == "barrelhiderSyncOutfit" then
		--managers.network._handlers.connection:sync_outfit(data, tonumber(string.match(id, "%d+")), "", managers.network:session():peer(peer_id))
		local peer = managers.network:session():peer(peer_id)
		peer:set_outfit_string(data, tonumber(string.match(id, "%d+")), "")
		if managers.network:session():is_host() then
			managers.network:session():chk_request_peer_outfit_load_status()
		end
		local local_peer = managers.network:session() and managers.network:session():local_peer()
		local in_lobby = local_peer and local_peer:in_lobby() and game_state_machine:current_state_name() ~= "ingame_lobby_menu" and not setup:is_unloading()
		if managers.menu_scene and in_lobby then
			managers.menu_scene:set_lobby_character_out_fit(peer:id(), data, peer:rank())
		end
		local kit_menu = managers.menu:get_menu("kit_menu")
		if kit_menu then
			kit_menu.renderer:set_slot_outfit(peer:id(), peer:character(), data)
		end
		log(string.match(id, "%w+") .. "|" .. string.match(id, "%d+") .. "|" .. data)
	end
end)

Hooks:Add("NetworkGameOnGameJoined", "barrelhiderOnGameJoined", function(local_peer, id)
	LuaNetworking:SendToPeers( "barrelhiderModPeer", "V1" )
	--MenuCallbackHandler:_update_outfit_information()
	log("send barrelhider OnGameJoined")
end)
Hooks:Add("NetworkManagerOnPeerAdded", "barrelhiderOnPeerAdded", function(peer, id)
	LuaNetworking:SendToPeers( "barrelhiderModPeer", "V1" )
	managers.network:session():check_send_outfit()
	log("send barrelhider OnPeerAdded")
end)
Hooks:Add("BaseNetworkSessionOnLoadComplete", "barrelhiderOnLoadComplete", function(peer, id)
	LuaNetworking:SendToPeers( "barrelhiderModPeer", "V1" )
	log("send barrelhider OnPeerAdded")
end)
Hooks:Add("BaseNetworkSessionOnPeerEnteredLobby", "peer_entered_lobby_test", function(peer, id)
	LuaNetworking:SendToPeers( "barrelhiderModPeer", "V1" )
	managers.network:session():check_send_outfit()
	log("send barrelhider OnPeerEnteredLobby")
end)