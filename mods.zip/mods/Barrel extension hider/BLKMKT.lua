old_dlc_init = DLCTweakData.init
function DLCTweakData:init(...)
        old_dlc_init(self, ...)
        self.barrelhidermods = {}
		self.barrelhidermods.content = {}
		self.barrelhidermods.content.loot_global_value = "normal"
		self.barrelhidermods.free = true
        self.barrelhidermods.content.loot_drops = {
 				{
				type_items = "weapon_mods",
				item_entry = "wpn_fps_upg_hidebarrelext",
				amount = 1
				}
				
		}
end

