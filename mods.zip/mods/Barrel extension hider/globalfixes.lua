_G.barrelhider_texture_fixes = {
	["wpn_fps_upg_hidebarrelext"] = "guis/textures/pd2/endscreen/what_is_this"
}

_G.barrelhider_peer_fixes = {
--	["wpn_fps_upg_hidebarrelext"] = "wpn_fps_upg_ass_ns_jprifles",

}