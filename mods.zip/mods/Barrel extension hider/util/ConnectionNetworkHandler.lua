function ConnectionNetworkHandler:send_barrelhider(value, sender)
	local peer = self._verify_sender(sender)
	if not peer then
		return
	end
	if value == "true" then
		peer:set_has_barrelhider(true)
		log("received barrelhider true")
	end
end