function BlackMarketManager:player_loadout_data(show_all_icons)
	local primary_texture = "guis/textures/pd2/endscreen/what_is_this"
	local primary_bg_texture = "guis/textures/pd2/endscreen/what_is_this"
	local secondary_texture = "guis/textures/pd2/endscreen/what_is_this"
	local secondary_bg_texture = "guis/textures/pd2/endscreen/what_is_this"
	local melee_weapon_texture = "guis/textures/pd2/endscreen/what_is_this"
	local grenade_texture = "guis/textures/pd2/endscreen/what_is_this"
	local armor_texture = "guis/textures/pd2/endscreen/what_is_this"
	local deployable_texture = "guis/textures/pd2/endscreen/what_is_this"
	local mask_texture = "guis/textures/pd2/endscreen/what_is_this"
	local character_texture = "guis/textures/pd2/endscreen/what_is_this"
	local empty_string = managers.localization:to_upper_text("menu_loadout_empty")
	local primary_string = empty_string
	local secondary_string = empty_string
	local melee_weapon_string = empty_string
	local grenade_string = empty_string
	local armor_string = empty_string
	local deployable_string = empty_string
	local mask_string = empty_string
	local character_string = empty_string
	local primary_perks = {}
	local secondary_perks = {}
	local primary = self:equipped_primary()
	local secondary = self:equipped_secondary()
	local melee_weapon = self:equipped_melee_weapon()
	local grenade, grenade_amount = self:equipped_grenade()
	local armor = self:equipped_armor()
	local deployable = managers.player:equipment_in_slot(1)
	local mask = self:equipped_mask()
	local character = self:get_preferred_character()
	if primary then
		primary_texture, primary_bg_texture = managers.blackmarket:get_weapon_icon_path(primary.weapon_id, primary.cosmetics)
		local equipped_weapon = self:equipped_primary()
		local equipped_slot = self:equipped_weapon_slot("primaries")
		primary_string = self:get_weapon_name_by_category_slot("primaries", equipped_slot)
		if equipped_weapon and equipped_slot then
			local icon_list = {}
			for i, icon in ipairs(managers.menu_component:create_weapon_mod_icon_list(equipped_weapon.weapon_id, "primaries", equipped_weapon.factory_id, equipped_slot)) do
				if show_all_icons or icon.equipped then
					table.insert(icon_list, icon)
				end
			end
			primary_perks = icon_list
		end
	end
	if secondary then
		secondary_texture, secondary_bg_texture = managers.blackmarket:get_weapon_icon_path(secondary.weapon_id, secondary.cosmetics)
		local equipped_weapon = self:equipped_secondary()
		local equipped_slot = self:equipped_weapon_slot("secondaries")
		secondary_string = self:get_weapon_name_by_category_slot("secondaries", equipped_slot)
		if equipped_weapon and equipped_slot then
			local icon_list = {}
			for i, icon in ipairs(managers.menu_component:create_weapon_mod_icon_list(equipped_weapon.weapon_id, "secondaries", equipped_weapon.factory_id, equipped_slot)) do
				if show_all_icons or icon.equipped then
					table.insert(icon_list, icon)
				end
			end
			secondary_perks = icon_list
		end
	end
	if melee_weapon then
		local guis_catalog = "guis/"
		local bundle_folder = tweak_data.blackmarket.melee_weapons[melee_weapon] and tweak_data.blackmarket.melee_weapons[melee_weapon].texture_bundle_folder
		if bundle_folder then
			guis_catalog = guis_catalog .. "dlcs/" .. tostring(bundle_folder) .. "/"
		end
		if melee_weapon == "weapon" then
			melee_weapon_texture = nil
		else
			melee_weapon_texture = barrelhider_texture_fixes[melee_weapon] or guis_catalog .. "textures/pd2/blackmarket/icons/melee_weapons/" .. tostring(melee_weapon)
		end
		melee_weapon_string = managers.localization:text(tweak_data.blackmarket.melee_weapons[melee_weapon].name_id)
	end
	if grenade and grenade_amount > 0 then
		local guis_catalog = "guis/"
		local bundle_folder = tweak_data.blackmarket.projectiles[grenade] and tweak_data.blackmarket.projectiles[grenade].texture_bundle_folder
		if bundle_folder then
			guis_catalog = guis_catalog .. "dlcs/" .. tostring(bundle_folder) .. "/"
		end
		grenade_texture = barrelhider_texture_fixes[grenade] or guis_catalog .. "textures/pd2/blackmarket/icons/grenades/" .. tostring(grenade)
		grenade_string = managers.localization:text(tweak_data.blackmarket.projectiles[grenade].name_id)
	end
	if armor then
		local guis_catalog = "guis/"
		local bundle_folder = tweak_data.blackmarket.armors[armor] and tweak_data.blackmarket.armors[armor].texture_bundle_folder
		if bundle_folder then
			guis_catalog = guis_catalog .. "dlcs/" .. tostring(bundle_folder) .. "/"
		end
		armor_texture = barrelhider_texture_fixes[armor] or guis_catalog .. "textures/pd2/blackmarket/icons/armors/" .. tostring(armor)
		armor_string = managers.localization:text(tweak_data.blackmarket.armors[armor].name_id)
	end
	if deployable then
		local guis_catalog = "guis/"
		local bundle_folder = tweak_data.blackmarket.deployables[deployable] and tweak_data.blackmarket.deployables[deployable].texture_bundle_folder
		if bundle_folder then
			guis_catalog = guis_catalog .. "dlcs/" .. tostring(bundle_folder) .. "/"
		end
		deployable_texture = barrelhider_texture_fixes[deployable] or guis_catalog .. "textures/pd2/blackmarket/icons/deployables/" .. tostring(deployable)
		deployable_string = managers.localization:text(tweak_data.upgrades.definitions[deployable].name_id)
	end
	
	if mask then
		local guis_catalog = "guis/"
		local bundle_folder = tweak_data.blackmarket.masks[mask.mask_id] and tweak_data.blackmarket.masks[mask.mask_id].texture_bundle_folder
		if bundle_folder then
			guis_catalog = guis_catalog .. "dlcs/" .. tostring(bundle_folder) .. "/"
		end
		mask_texture = barrelhider_texture_fixes[mask.mask_id] or tweak_data.blackmarket.masks[mask.mask_id].texture or guis_catalog .. "textures/pd2/blackmarket/icons/masks/" .. tostring(mask.mask_id) 
	--Redirects the game to pull the main inventory mask gui icon from the location indicated in the main hook.

		local equipped_slot = self:equipped_weapon_slot("masks")
		mask_string = self:get_mask_name_by_category_slot("masks", equipped_slot)
	end

	if character then
		local character_name = CriminalsManager.convert_old_to_new_character_workname(character)
		local guis_catalog = "guis/"
		local character_table = tweak_data.blackmarket.characters[character] or tweak_data.blackmarket.characters.locked[character_name]
		local bundle_folder = character_table and character_table.texture_bundle_folder
		if bundle_folder then
			guis_catalog = guis_catalog .. "dlcs/" .. tostring(bundle_folder) .. "/"
		end
		character_texture = guis_catalog .. "textures/pd2/blackmarket/icons/characters/" .. tostring(character_name)
		character_string = managers.localization:text("menu_" .. character)
	end
	local primary = {
		item_texture = primary_texture or false,
		item_bg_texture = primary_bg_texture,
		info_text = primary_string,
		info_icons = primary_perks
	}
	local secondary = {
		item_texture = secondary_texture or false,
		item_bg_texture = secondary_bg_texture,
		info_text = secondary_string,
		info_icons = secondary_perks
	}
	local melee_weapon = {
		item_texture = melee_weapon_texture or false,
		info_text = melee_weapon_string,
		dual_texture_1 = primary_texture or false,
		dual_texture_2 = secondary_texture or false
	}
	local grenade = {
		item_texture = grenade_texture or false,
		info_text = grenade_string
	}
	local armor = {
		item_texture = armor_texture or false,
		info_text = armor_string
	}
	local deployable = {
		item_texture = deployable_texture or false,
		info_text = deployable_string
	}
	local mask = {
		item_texture = mask_texture or false,
		info_text = mask_string
	}
	local character = {
		item_texture = character_texture or false,
		info_text = character_string
	}
	return {
		primary = primary,
		secondary = secondary,
		melee_weapon = melee_weapon,
		grenade = grenade,
		armor = armor,
		deployable = deployable,
		mask = mask,
		character = character
	}
end