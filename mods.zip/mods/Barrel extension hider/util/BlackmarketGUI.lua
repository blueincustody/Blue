CloneClass(BlackMarketGui)

Hooks:Register("BlackMarketGUIPopulateDataCall")
if GoonBase and GoonBase.Updates:GameUpdateVersionCheck() then
	Hooks:Add("BlackMarketGUIOnPopulateModsActionList", "barrelhiderPopulateMods", function(blackmarketgui, data)
		blackmarketgui:barrelhider_texture_fix(data)
	end)
	Hooks:Add("BlackMarketGUIOnPopulateMasksActionList", "barrelhiderPopulateMasks", function(blackmarketgui, data)
		blackmarketgui:barrelhider_texture_fix(data)
	end)
	Hooks:Add("BlackMarketGUIOnPopulateBuyMasksActionList", "barrelhiderPopulateBuyMasks", function(blackmarketgui, data)
		blackmarketgui:barrelhider_texture_fix(data)
	end)
	Hooks:Add("BlackMarketGUIOnPopulateMeleeWeaponActionList", "barrelhiderPopulateMelee", function(blackmarketgui, data)
		blackmarketgui:barrelhider_texture_fix(data)
	end)

	Hooks:Add("BlackMarketGUIOnPopulateMeleeWeaponActionList", "barrelhiderPopulateMelee", function(blackmarketgui, data)
		blackmarketgui:barrelhider_texture_fix(data)
	end)
else
	function BlackMarketGui.populate_mods(self, data)
		self.orig.populate_mods(self, data)
		--self:barrelhider_texture_fix(data)
		Hooks:Call("BlackMarketGUIPopulateDataCall", self, data)
	end
	function BlackMarketGui.populate_masks(self, data)
		self.orig.populate_masks(self, data)
		--self:barrelhider_texture_fix(data)
		Hooks:Call("BlackMarketGUIPopulateDataCall", self, data)
	end
	function BlackMarketGui.populate_masks_new(self, data)
		self.orig.populate_masks_new(self, data)
		--self:barrelhider_texture_fix(data)
		Hooks:Call("BlackMarketGUIPopulateDataCall", self, data)
	end
	function BlackMarketGui.populate_buy_mask(self, data)
		self.orig.populate_buy_mask(self, data)
		--self:barrelhider_texture_fix(data)
		Hooks:Call("BlackMarketGUIPopulateDataCall", self, data)
	end
	function BlackMarketGui.populate_melee_weapons(self, data)
		self.orig.populate_melee_weapons(self, data)
		--self:barrelhider_texture_fix(data)
		Hooks:Call("BlackMarketGUIPopulateDataCall", self, data)
	end
end

function BlackMarketGui.populate_grenades(self, data)
	self.orig.populate_grenades(self, data)
	--self:barrelhider_texture_fix(data)
	Hooks:Call("BlackMarketGUIPopulateDataCall", self, data)
end

Hooks:Add("BlackMarketGUIPopulateDataCall", "barrelhiderPopulateDataCall", function(blackmarketgui, data)
	blackmarketgui:barrelhider_texture_fix(data)
end)

function BlackMarketGui:barrelhider_texture_fix(data, skip_goon)
	if (GoonBase and GoonBase.SupportedVersion) and not skip_goon then
		if data.name and barrelhider_texture_fixes[data.name] then
			data.bitmap_texture = barrelhider_texture_fixes[data.name]
		end
	else
		for p, d in pairs(data) do
			if type(d) == "table" then
				if d.name and barrelhider_texture_fixes[d.name] then
					d.bitmap_texture = barrelhider_texture_fixes[d.name]
				end
			end
		end
	end
end