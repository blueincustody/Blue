function BaseNetworkSession:check_send_outfit(peer, barrelhider)
	local Net = _G.LuaNetworking
	if not barrelhider then
		Net:SendToPeers( "barrelhiderModPeer", "V1" )
	end
	local outfit_string = managers.blackmarket:outfit_string()
	local modded_outfit = outfit_string
	for id, replacement in pairs(barrelhider_peer_fixes) do
		modded_outfit = string.gsub(modded_outfit, id, replacement)
	end
	for i = 1, 4 do
		local peer = managers.network:session():peer(i)
		if peer and peer ~= self:local_peer() then
			if peer:has_barrelhider() then
				Net:SendToPeers( "barrelhiderSyncOutfit " .. self:local_peer():outfit_version(), outfit_string )
				--peer:send("sync_outfit", outfit_string, self:local_peer():outfit_version(), "")
			else
				peer:send("sync_outfit", modded_outfit, self:local_peer():outfit_version(), "")
			end
		end
	end
end