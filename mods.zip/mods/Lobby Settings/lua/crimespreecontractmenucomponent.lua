local ls_original_menucrimenetcrimespreecontractinitiator_modifynode = MenuCrimeNetCrimeSpreeContractInitiator.modify_node
function MenuCrimeNetCrimeSpreeContractInitiator:modify_node(original_node, data)
	local node = ls_original_menucrimenetcrimespreecontractinitiator_modifynode(self, original_node, data)

	if Global.game_settings.single_player then
		-- Nothing
	elseif data.smart_matchmaking then
		-- Nothing
	elseif data.id == "crime_spree" and node:item('lobby_reputation_permission'):visible() then
		LobbySettings:InsertInfamyLimiter(node)
		LobbySettings:InsertPlayerLimiter(node)
	end

	return node
end
