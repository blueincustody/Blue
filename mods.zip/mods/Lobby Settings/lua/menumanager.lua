_G.LobbySettings = _G.LobbySettings or {}
LobbySettings._path = ModPath
LobbySettings._data_path = SavePath .. 'lobby_settings.txt'

function LobbySettings:Save()
	local file = io.open(self._data_path, 'w+')
	if file then
		local settings = {
			lobby_permission = Global.game_settings.permission,
			reputation_permission = Global.game_settings.reputation_permission,
			infamy_permission = Global.game_settings.infamy_permission,
			max_players = Global.game_settings.max_players
		}
		file:write(json.encode(settings))
		file:close()
	end
end

function LobbySettings:Load()
	local file = io.open(self._data_path, 'r')
	local settings = {}
	if file then
		settings = json.decode(file:read('*all'))
		file:close()
	end
	Global.game_settings.permission = settings.lobby_permission or 'friends_only'
	Global.game_settings.infamy_permission = settings.infamy_permission or 0
	Global.game_settings.reputation_permission = settings.reputation_permission or 0
	Global.game_settings.max_players = settings.max_players or tweak_data.max_players
end

Hooks:Add('LocalizationManagerPostInit', 'LocalizationManagerPostInit_LobbySettings', function(loc)
	for _, filename in pairs(file.GetFiles(LobbySettings._path .. 'loc/')) do
		local str = filename:match('^(.*).txt$')
		if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
			loc:load_localization_file(LobbySettings._path .. 'loc/' .. filename)
			break
		end
	end

	loc:load_localization_file(LobbySettings._path .. 'loc/english.txt', false)
end)

Hooks:Add('MenuManagerInitialize', 'MenuManagerInitialize_LobbySettings', function(menu_manager)
	LobbySettings:Load()

	local ls_original_menucallbackhandler_choicelobbypermission = MenuCallbackHandler.choice_lobby_permission
	function MenuCallbackHandler:choice_lobby_permission(...)
		ls_original_menucallbackhandler_choicelobbypermission(self, ...)
		LobbySettings:Save()
	end

	local ls_original_menucallbackhandler_choicecrimenetlobbypermission = MenuCallbackHandler.choice_crimenet_lobby_permission
	function MenuCallbackHandler:choice_crimenet_lobby_permission(...)
		ls_original_menucallbackhandler_choicecrimenetlobbypermission(self, ...)
		LobbySettings:Save()
	end

	local ls_original_menucallbackhandler_choicelobbyreputationpermission = MenuCallbackHandler.choice_lobby_reputation_permission
	function MenuCallbackHandler:choice_lobby_reputation_permission(...)
		ls_original_menucallbackhandler_choicelobbyreputationpermission(self, ...)
		LobbySettings:Save()
	end

	function MenuCallbackHandler:ls_choice_lobby_infamy_permission(item)
		local infamy_permission = item:value()
		Global.game_settings.infamy_permission = infamy_permission
		if LobbySettings.egs_item_infamy and item ~= LobbySettings.egs_item_infamy then
			LobbySettings.egs_item_infamy:set_value(infamy_permission)
		end
		LobbySettings:Save()
	end

	function MenuCallbackHandler:ls_choice_lobby_max_players(item)
		local max_players = item:value()
		Global.game_settings.max_players = max_players
		if LobbySettings.egs_item_max_players and item ~= LobbySettings.egs_item_max_players then
			LobbySettings.egs_item_max_players:set_value(max_players)
		end
		if Network:is_server() then
			managers.network:session():chk_server_joinable_state()
		end
		LobbySettings:Save()
	end

	function MenuCallbackHandler:ls_infamy_check(data)
		return data:value() <= managers.experience:current_rank()
	end
end)

Hooks:Add('MenuManagerBuildCustomMenus', 'MenuManagerBuildCustomMenus_LobbySettings', function(menu_manager, nodes)
	if nodes.edit_game_settings then
		LobbySettings.egs_item_infamy = LobbySettings:InsertInfamyLimiter(nodes.edit_game_settings)
		LobbySettings.egs_item_max_players = LobbySettings:InsertPlayerLimiter(nodes.edit_game_settings)
	end
end)

function LobbySettings:InsertInfamyLimiter(node)
	local data = {
		type = "MenuItemMultiChoice"
	}

	for i = 0, 25 do
		local option = {
			_meta = 'option',
			localize = false,
			text_id = i,
			value = i,
			visible_callback = 'ls_infamy_check'
		}
		table.insert(data, option)
	end

	local params = {
		name = 'ls_multi_infamy_permission',
		text_id = 'ls_menu_infamy_permission',
		help_id = 'ls_menu_infamy_permission_help',
		callback = 'ls_choice_lobby_infamy_permission',
		localize = true,
		visible_callback = 'is_multiplayer'
	}

	local item = node:create_item(data, params)
	item:set_value(Global.game_settings.infamy_permission)
	item:set_callback_handler(node.callback_handler)

	for k, v in pairs(node._items) do
		if v._parameters.name == 'lobby_reputation_permission' then
			table.insert(node._items, k, item)
			break
		end
	end

	return item
end

function LobbySettings:InsertPlayerLimiter(node)
	local data = {
		type = "MenuItemMultiChoice"
	}

	for i = 1, tweak_data.max_players do
		local option = {
			_meta = 'option',
			localize = false,
			text_id = i,
			value = i
		}
		table.insert(data, option)
	end

	local params = {
		name = 'ls_multi_max_players',
		text_id = 'ls_menu_max_players',
		help_id = 'ls_menu_max_players_help',
		callback = 'ls_choice_lobby_max_players',
		localize = true,
		visible_callback = 'is_multiplayer'
	}

	local item = node:create_item(data, params)
	item:set_value(Global.game_settings.max_players)
	item:set_callback_handler(node.callback_handler)

	for k, v in pairs(node._items) do
		if v._parameters.name == 'lobby_permission' then
			table.insert(node._items, k, item)
			break
		end
	end

	return item
end

local ls_original_menucrimenetcontractinitiator_modifynode = MenuCrimeNetContractInitiator.modify_node
function MenuCrimeNetContractInitiator:modify_node(original_node, data)
	local node = ls_original_menucrimenetcontractinitiator_modifynode(self, original_node, data)

	if Global.game_settings.single_player then
		-- Nothing
	elseif data.smart_matchmaking then
		-- Nothing
	elseif not data.server and node:item('lobby_reputation_permission'):visible() then
		LobbySettings:InsertInfamyLimiter(node)
		LobbySettings:InsertPlayerLimiter(node)
	end

	return node
end
