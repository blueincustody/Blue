local ls_original_hostnetworksession_onjoinrequestreceived = HostNetworkSession.on_join_request_received
function HostNetworkSession:on_join_request_received(peer_name, preferred_character, dlcs, xuid, peer_level, peer_rank, gameversion, join_attempt_identifier, auth_ticket, sender)
	if peer_rank < (Global.game_settings.infamy_permission or 0) then
		local my_user_id = self._state_data.local_peer:user_id() or ''
		self._state:_send_request_denied(sender, 6, my_user_id)
		return
	end

	if Global.game_settings.max_players - 1 <= table.size(self._state_data.peers) then
		local my_user_id = self._state_data.local_peer:user_id() or ''
		self._state:_send_request_denied(sender, 5, my_user_id)
		return
	end

	return ls_original_hostnetworksession_onjoinrequestreceived(self, peer_name, preferred_character, dlcs, xuid, peer_level, peer_rank, gameversion, join_attempt_identifier, auth_ticket, sender)
end
