local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_sprinter_beta_desc" and "BASIC: ##1 point##\nYour stamina starts regenerating ##25%## earlier and ##25%## faster. You also sprint ##25%## faster.\n\nACE: ##3 points##\nYou have ##10%## increased chance to dodge while sprinting. You gain ##15%## chance to dodge while crouching or ziplining."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end