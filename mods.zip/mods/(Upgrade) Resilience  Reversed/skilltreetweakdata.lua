local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.sprinter = {
		["name_id"] = "menu_sprinter_beta",
		["desc_id"] = "menu_sprinter_beta_desc",
		["icon_xy"] = {10, 5},
		[1] = {
			upgrades = {
				"player_stamina_regen_timer_multiplier",
				"player_stamina_regen_multiplier",
				"player_run_speed_multiplier",
				"player_run_dodge_chance"
			},
			cost = self.costs.default
		},
		[2] = {
			upgrades = {
				"player_stamina_regen_timer_multiplier",
				"player_stamina_regen_multiplier",
				"player_run_speed_multiplier",
				"player_run_dodge_chance"
			},
			cost = self.costs.pro
		}
	}
end	