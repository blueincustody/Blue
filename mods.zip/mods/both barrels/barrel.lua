local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)

-- Mosconi --	
self.huntsman.CAN_TOGGLE_FIREMODE = true
self.huntsman.auto = {}
self.huntsman.auto.fire_rate = 0.00
self.huntsman.fire_mode_data.fire_rate = 0.001
self.huntsman.sounds.fire_single = "huntsman_fire"
self.huntsman.sounds.fire_auto = "huntsman_fire"
-- Joceline --
self.b682.CAN_TOGGLE_FIREMODE = true
self.b682.auto = {}
self.b682.auto.fire_rate = 0.00
self.b682.fire_mode_data.fire_rate = 0.001
self.b682.sounds.fire_single = "b682_fire"
self.b682.sounds.fire_auto = "b682_fire"
end