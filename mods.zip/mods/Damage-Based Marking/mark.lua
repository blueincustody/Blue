local mvec3_dis = mvector3.distance
local old_received = CopDamage._on_damage_received
function CopDamage:_on_damage_received(damage_info, ...)
	local result = damage_info.result
	if result then
		if not result.type or result.type ~= "death" then
			local variant = damage_info.variant
			if not variant or variant ~= "explosion" then
				local attacker_unit = damage_info.attacker_unit
				if attacker_unit then
					if attacker_unit == managers.player:player_unit() then
						local attack_dis = mvec3_dis(attacker_unit:position(), self._unit:position())
						local spotting_mul = managers.player:upgrade_value("player", "marked_distance_mul", 1)
						local range_mul = managers.player:upgrade_value("player", "intimidate_range_mul", 1) * managers.player:upgrade_value("player", "passive_intimidate_range_mul", 1)
						local highlight_range = tweak_data.player.long_dis_interaction.highlight_range * range_mul * spotting_mul
						if attack_dis <= highlight_range then
							local char_tweak = tweak_data.character[self._unit:base()._tweak_table]
							if char_tweak then
								local priority_shout = char_tweak.priority_shout
								if priority_shout then
									local unit_contour = self._unit:contour()
									if unit_contour then
										if not unit_contour._contour_list then
											local unit_sound = attacker_unit:sound()
											if unit_sound then
												if not unit_sound:speaking() then
													local sound_name = priority_shout .. "x_any"
													if sound_name then
														unit_sound:say(sound_name, true, true)
														unit_contour:add(managers.player:get_contour_for_marked_enemy(), true, managers.player:upgrade_value("player", "mark_enemy_time_multiplier", 1))
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
	return old_received(self, damage_info, ...)
end