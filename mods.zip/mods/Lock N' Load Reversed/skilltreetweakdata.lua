local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.shock_and_awe = {
		["name_id"] = "menu_shock_and_awe_beta",
		["desc_id"] = "menu_shock_and_awe_beta_desc",
		["icon_xy"] = {10, 0},
		[1] = {
			upgrades = {
				"player_automatic_faster_reload_1"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {
				"player_run_and_shoot_1"
			},
			cost = self.costs.hightierpro
		}
	}
end	