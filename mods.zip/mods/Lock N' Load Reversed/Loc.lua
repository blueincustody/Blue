local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_shock_and_awe_beta_desc" and "BASIC: ##3 points##\nKilling ##2## enemies with SMGs, LMGs, Assault Rifles or Special Weapons set on automatic fire mode will increase your next reload speed by up to ##100%##. This bonus is reduced by ##1%## for each bullet above ##20## in the total magazine size, down to a minimum of ##40%## reload speed increase. \n\nACE: ##6 points##\nYou can now hip-fire with your weapons while sprinting."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end