local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
    data(self, tweak_data)
	self.skills.messiah = {
		["name_id"] = "menu_pistol_beta_messiah",
		["desc_id"] = "menu_pistol_beta_messiah_desc",
		["icon_xy"] = {2, 9},
		[1] = {
			upgrades = {
				"player_messiah_revive_from_bleed_out_1",
				"player_recharge_messiah_1"
			},
			cost = self.costs.hightier
		},
		[2] = {
			upgrades = {},
			cost = self.costs.hightierpro
		}
	}
end	