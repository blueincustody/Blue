local text_original = LocalizationManager.text
function LocalizationManager:text(string_id, ...)
return string_id == "menu_pistol_beta_messiah_desc" and "BASIC: ##4 points##\nWhile in bleedout, you can revive yourself if you kill an enemy. You only have #1# charge.\n\nACE: ##8 points##\nYour Messiah charge is replenished whenever you use a doctor bag."
or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end