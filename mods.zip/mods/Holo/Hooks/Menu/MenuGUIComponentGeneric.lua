Holo:Post(MenuGuiComponentGeneric, "_add_back_button", function(self)
	Holo.Utils:FixBackButton(self, self._panel:child("back_button"))
end)