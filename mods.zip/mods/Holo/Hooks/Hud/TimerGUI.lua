TimerGui.upgrade_colors.upgrade_color_0 = Color(0.09, 0.12, 0.14)
TimerGui.upgrade_colors.upgrade_color_1 = Color.white