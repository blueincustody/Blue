local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)

self.c96.CAN_TOGGLE_FIREMODE = true
self.c96.has_description = true
self.c96.auto = {}
self.c96.FIRE_MODE = "auto"
self.c96.auto.fire_rate = 0.00
self.c96.fire_mode_data.fire_rate = 0.080
self.c96.sounds.fire_single = "c96_fire"
self.c96.sounds.fire_auto = "c96_fire"
end