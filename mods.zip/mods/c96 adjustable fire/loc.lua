Hooks:Add("LocalizationManagerPostInit", "weapon_mod_Localization", function(loc)
	LocalizationManager:add_localized_strings({
		["bm_w_c96_desc"] = "The Schnellfeuer was introduced in the early 1930s in response to the select-fire C96 copies produced in Spain in the late 1920s. It used ten- or twenty-round detachable magazines and a select-fire mechanism designed by Joseph Nickl (1930-1932), later improved by Karl Westinger (1932-1936), the most commonly seen. The Schnellfeuer is popularly known as the M712, its Wehrmacht designation during World War 2.",
		["bm_w_c96"] = "Mauser M712 Schnellfeuer"
	})
end)