if _G.Iter_CoreMissionManager then
	return
end
_G.Iter_CoreMissionManager = true

_G.Iter = _G.Iter or {}
Iter._path = ModPath
Iter._data_path = SavePath .. 'iter.txt'
Iter.settings = {
	streamline_path = true,
	map_change_alex_1 = true,
	map_change_alex_2 = true,
	map_change_arena = true,
	map_change_arm_for = true,
	map_change_born = true,
	map_change_cane = true,
	map_change_firestarter_1 = true,
	map_change_flat = true,
	map_change_friend = true,
	map_change_jolly = true,
	map_change_kosugi = true,
	map_change_mad = true,
	map_change_mia_1 = true,
	map_change_moon = true,
	map_change_pbr2 = true,
	map_change_peta = true,
	map_change_rat = true,
	map_change_red2 = true,
	map_change_watchdogs_1 = true
}

function Iter:Load()
	local file = io.open(self._data_path, 'r')
	if file then
		for k, v in pairs(json.decode(file:read('*all')) or {}) do
			self.settings[k] = v
		end
		file:close()
	end
end

function Iter:Save()
	local file = io.open(self._data_path, 'w+')
	if file then
		file:write(json.encode(self.settings))
		file:close()
	end
end

Iter:Load()

Hooks:Add('LocalizationManagerPostInit', 'LocalizationManagerPostInit_Iter', function(loc)
	for _, filename in pairs(file.GetFiles(Iter._path .. 'loc/')) do
		local str = filename:match('^(.*).txt$')
		if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
			loc:load_localization_file(Iter._path .. 'loc/' .. filename)
			break
		end
	end

	loc:load_localization_file(Iter._path .. 'loc/english.txt', false)
end)

Hooks:Add('MenuManagerInitialize', 'MenuManagerInitialize_Iter', function(menu_manager)

	MenuCallbackHandler.IterStreamlinePath = function(this, item)
		Iter.settings.streamline_path = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeAlex1 = function(this, item)
		Iter.settings.map_change_alex_1 = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeAlex2 = function(this, item)
		Iter.settings.map_change_alex_2 = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeArmFor = function(this, item)
		Iter.settings.map_change_arm_for = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeBorn = function(this, item)
		Iter.settings.map_change_born = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeCane = function(this, item)
		Iter.settings.map_change_cane = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeFirestarter1 = function(this, item)
		Iter.settings.map_change_firestarter_1 = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeFlat = function(this, item)
		Iter.settings.map_change_flat = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeFriend = function(this, item)
		Iter.settings.map_change_friend = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeJolly = function(this, item)
		Iter.settings.map_change_jolly = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeKosugi = function(this, item)
		Iter.settings.map_change_kosugi = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeMad = function(this, item)
		Iter.settings.map_change_mad = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeMia1 = function(this, item)
		Iter.settings.map_change_mia_1 = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeMoon = function(this, item)
		Iter.settings.map_change_moon = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangePbr2 = function(this, item)
		Iter.settings.map_change_pbr2 = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangePeta = function(this, item)
		Iter.settings.map_change_peta = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeRat = function(this, item)
		Iter.settings.map_change_rat = item:value() == 'on'
	end

	MenuCallbackHandler.IterMapChangeWatchdogs1 = function(this, item)
		Iter.settings.map_change_watchdogs_1 = item:value() == 'on'
	end

	MenuCallbackHandler.IterSave = function(this, item)
		Iter:Save()
	end

	MenuHelper:LoadFromJsonFile(Iter._path .. 'menu/options.txt', Iter, Iter.settings)

end)

core:module('CoreMissionManager')
core:import('CoreTable')

local level_id = Global.game_settings and Global.game_settings.level_id or ''
local itr_original_missionmanager_addscript = MissionManager._add_script
local itr_original_missionscript_createelements = MissionScript._create_elements

if not _G.Iter.settings['map_change_' .. level_id] then

elseif level_id == 'kosugi' then

	function MissionScript:_create_elements(elements)
		for _, element in pairs(elements) do
			if element.id == 102617 then
				table.insert(element.values.on_executed, { delay = 0, id = 105000 })
			elseif element.id == 102626 then
				table.insert(element.values.on_executed, { delay = 0, id = 105000 })
				local element105000 = {
					id = 105000,
					module = 'CoreElementToggle',
					editor_name = 'ITR_toggle_SO',
					class = 'ElementToggle',
					values = {
						enabled = true,
						on_executed = {},
						elements = {
							103543,
							103545
						},
						set_trigger_times = -1,
						execute_on_startup = false,
						trigger_times = 0,
						toggle = 'on',
						base_delay = 0
					}
				}
				table.insert(elements, element105000)
			elseif element.id == 103543 or element.id == 103545 then
				element.values.enabled = false
			elseif element.id == 103675 then
				table.insert(element.values.unit_ids, 100381)
			end
		end
		return itr_original_missionscript_createelements(self, elements)
	end

elseif level_id == 'cane' then

	function MissionScript:_create_elements(elements)
		for _, element in pairs(elements) do
			if element.id == 136356 then
				element.values.on_executed[1].id = 136446
			end
		end
		return itr_original_missionscript_createelements(self, elements)
	end

elseif level_id == 'friend' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 103880 then
				table.insert(element.values.on_executed, { delay = 0, id = 105000 })
			elseif element.id == 103877 then
				table.insert(element.values.on_executed, { delay = 0, id = 105001 })
				local element105000 = {
					id = 105000,
					class = 'ElementAINavSeg',
					values = {
						enabled = true,
						operation = 'remove_nav_seg_neighbours',
						base_delay = 0,
						on_executed = {},
						execute_on_startup = false,
						trigger_times = 0,
						segment_ids = { 106, 55, 55, 106 }
					},
					editor_name = 'ITR_remove_link1'
				}
				table.insert(data.elements, element105000)

				local element105001 = CoreTable.deep_clone(element105000)
				element105001.id = 105001
				element105001.values.segment_ids = { 71, 55, 55, 71 }
				element105001.editor_name = 'ITR_remove_link2'
				table.insert(data.elements, element105001)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif (level_id == 'rat' or level_id == 'alex_1') and Network:is_server() then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.editor_name == 'playersEnteredSniperPosition' then
				table.insert(element.values.on_executed, { delay = 0, id = 102659 })
				table.insert(element.values.on_executed, { delay = 0, id = 102660 })
			elseif element.editor_name == 'SO_teammate_shortcut007' then
				local roof_down = CoreTable.deep_clone(element)
				roof_down.editor_name = 'SO_teammate_shortcut_roof_down'
				roof_down.id = 102659
				roof_down.values.so_action = 'e_nl_dwn_3_75m'
				roof_down.values.position = Vector3(2235, 973, 2097)
				roof_down.values.rotation = Rotation(-90, 0, 0)
				roof_down.values.search_position = Vector3(2395, 595, 1718)
				roof_down.values.interval = 2
				table.insert(data.elements, roof_down)
			elseif element.editor_name == 'SO_shortcut013' then
				local roof_up = CoreTable.deep_clone(element)
				roof_up.editor_name = 'SO_teammate_shortcut_roof_up'
				roof_up.id = 102660
				roof_up.values.position = Vector3(2455, 800, 1726)
				roof_up.values.search_position = Vector3(2200, 800, 2100.55)
				roof_up.values.rotation = Rotation(90, -0, -0)
				roof_up.values.path_haste = 'none'
				roof_up.values.so_action = 'e_nl_ladder_up_3m'
				roof_up.values.interval = 2
				table.insert(data.elements, roof_up)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'jolly' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 100406 then
				table.remove(element.values.on_executed, 308)
				table.insert(element.values.on_executed, { delay = 0, id = 101785 })
				table.insert(element.values.on_executed, { delay = 0, id = 101786 })
				table.insert(element.values.on_executed, { delay = 0, id = 101787 })
				table.insert(element.values.on_executed, { delay = 0, id = 101788 })
			elseif element.id == 101124 then
				element.values.repeatable = true
				element.values.so_action = 'e_nl_down_1m'
				element.values.align_position = false
				element.values.rotation = Rotation(103, 0, -0)
				element.values.position = Vector3(4686.31, 2489.63, 92.0396)
				element.values.search_position = Vector3(4553.26, 2456.52, -0.951866)
			elseif element.id == 100544 then
				local ladder1 = CoreTable.deep_clone(element)
				ladder1.editor_name = 'SO_teammate_ladder1'
				ladder1.id = 101785
				ladder1.values.align_position = true
				ladder1.values.attitude = 'avoid'
				ladder1.values.interval = 2
				ladder1.values.repeatable = true
				ladder1.values.so_action = 'e_nl_up_6m_var3'
				ladder1.values.path_style = 'destination'
				ladder1.values.rotation = Rotation(-150, -0, -0)
				ladder1.values.position = Vector3(-1533, 6530, 607)
				ladder1.values.search_position = Vector3(-1547, 6260, 1212)
				table.insert(data.elements, ladder1)
				local ladder2 = CoreTable.deep_clone(ladder1)
				ladder2.editor_name = 'SO_teammate_ladder2'
				ladder2.id = 101786
				ladder2.values.rotation = Rotation(0, -0, -0)
				ladder2.values.position = Vector3(-1583, -325, 607)
				ladder2.values.search_position = Vector3(-1538, -80, 1212)
				table.insert(data.elements, ladder2)
				local ladder3 = CoreTable.deep_clone(ladder1)
				ladder3.editor_name = 'SO_teammate_ladder3'
				ladder3.id = 101787
				ladder3.values.so_action = 'e_nl_cs_up_8m_ladder'
				ladder3.values.rotation = Rotation(180, -0, -0)
				ladder3.values.position = Vector3(2353, 6485, 300)
				ladder3.values.search_position = Vector3(2352, 6262, 1213)
				table.insert(data.elements, ladder3)
				local ladder4 = CoreTable.deep_clone(ladder3)
				ladder4.editor_name = 'SO_teammate_ladder4'
				ladder4.id = 101788
				ladder4.values.rotation = Rotation(0, -0, -0)
				ladder4.values.position = Vector3(2364, -315, 300)
				ladder4.values.search_position = Vector3(2360, -118, 1217)
				table.insert(data.elements, ladder4)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'moon' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 104665 then
				for i = 1, 5 do
					table.remove(element.values.on_executed, 1)
				end
			elseif element.id == 101144 then
				element.values.search_position = Vector3(490, -1258, 400)
			elseif element.id == 101445 then
				element.values.search_position = Vector3(490, -1258, 400)
			elseif element.id == 103774 then
				element.values.search_position = Vector3(62, -1232, 400)
			elseif element.id == 103775 then
				element.values.search_position = Vector3(62, -1232, 400)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'peta' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 100479 then
				table.remove(element.values.obstacle_list, 7)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'flat' then

	local function itr_mk_toggle(id, ...)
		local element = {
			id = id,
			module = 'CoreElementToggle',
			editor_name = 'ITR_toggle_window_trigger_area_' .. id,
			class = 'ElementToggle',
			values = {
				enabled = true,
				on_executed = {},
				elements = { ... },
				execute_on_startup = false,
				trigger_times = 1,
				toggle = 'on',
				base_delay = 0
			}
		}
		return element
	end

	local function itr_mk_trigger(id, so_id, toggle_id, pos)
		local element = {
			id = id,
			editor_name = 'ITR_SO_trigger_window_toggle_' .. id,
			class = 'ElementSpecialObjectiveTrigger',
			values = {
				enabled = true,
				on_executed = {
					{ delay = 0, id = toggle_id }
				},
				elements = { so_id },
				event = 'anim_act_04',
				execute_on_startup = false,
				trigger_times = 1,
				base_delay = 0,
				position = pos,
				rotation = Rotation(0, 0, -0)
			}
		}
		return element
	end

	local window_to_SO = {
		[100031] = 101063,
		[100047] = 101257,
		-- [100063] = ?,
		-- [102237] = ?,
		[102326] = 102141,
		[102327] = 100352,
		[102609] = 103253,
		[103282] = 102200,
		-- [103399] = ?,
		-- [103420] = ?,
	}
	function MissionManager:_add_script(data)
		local insert_id = 105000
		local SOs = {}
		for _, element in pairs(data.elements) do
			if element.id == 104122 then
				table.insert(element.values.elements, 104832)

			elseif element.id == 104150 then
				table.insert(element.values.elements, 104833)

			elseif element.editor_name:find('check enemy touch window') then
				element.values.enabled = false
				local so_id = window_to_SO[element.id]
				if so_id then
					SOs[so_id] = true
					table.insert(data.elements, itr_mk_toggle(insert_id, element.id))
					table.insert(data.elements, itr_mk_trigger(insert_id + 1, window_to_SO[element.id], insert_id, element.values.position))
					insert_id = insert_id + 2
				end
			end
		end
		for _, element in pairs(data.elements) do
			if SOs[element.id] then
				element.values.scan = true
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'arena' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 102016 or element.id == 102090 then
				element.values.enabled = false
			elseif element.id == 101004 then
				element.values.search_position = Vector3(-3423, -108, 800)
			elseif element.id == 101331 then
				element.values.search_position = Vector3(-342.589, 293.87, 0)
			elseif element.id == 101332 then
				element.values.search_position = Vector3(300, 295, 0)
			elseif element.id == 101333 then
				element.values.search_position = Vector3(300, 295, 0)
			elseif element.id == 101662 then
				element.values.search_position = Vector3(570, 1528, 0)
			elseif element.id == 101665 then
				element.values.search_position = Vector3(570, 1425, 0)
			elseif element.id == 101677 then
				element.values.search_position = Vector3(570, 1715, 0)
			elseif element.id == 102756 then
				element.values.search_position = Vector3(570, 1425, 0)
			elseif element.id == 102757 then
				element.values.search_position = Vector3(570, 1715, 0)
			elseif element.id == 102758 then
				element.values.search_position = Vector3(275, 1650, 0)
			elseif element.id == 102759 then
				element.values.search_position = Vector3(288, 1528, 0)
			elseif element.id == 102767 then
				element.values.search_position = Vector3(54, 1247, 0)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'watchdogs_1' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 103619 then
				element.values.position = Vector3(-1501, 2350, 825)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'red2' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 102449 then
				element.values.position = Vector3(-55, 1905, -25)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'pbr2' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 100063 then
				table.remove(element.values.on_executed, 2)
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

elseif level_id == 'firestarter_1' then

	function MissionManager:_add_script(data)
		for _, element in pairs(data.elements) do
			if element.id == 100411 then
				local ai_graph = CoreTable.deep_clone(element)
				ai_graph.id = 105000
				ai_graph.values.graph_ids[1] = 24
				table.insert(data.elements, ai_graph)
			elseif element.id == 100409 then
				table.insert(element.values.on_executed, { delay = 0, id = 105000 })
			end

			if element.id == 104355 or element.id == 104356 then
				local new_seq = CoreTable.deep_clone(element)
				new_seq.id = new_seq.id + 646
				element.values.sequence_list[1].sequence = 'int_seq_bullet_hit'
			end
		end
		itr_original_missionmanager_addscript(self, data)
	end

end
